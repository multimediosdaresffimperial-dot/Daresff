import {
  BedDouble,
  CalendarCheck,
  Download,
  History,
  KeyRound,
  LayoutGrid,
  Plus,
  Receipt,
  Search,
  ShoppingBasket,
  Store,
  Trash2,
  Upload,
} from "lucide-react";
import { useEffect, useMemo, useState, type ReactNode } from "react";
import { toast, Toaster } from "sonner";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Dialog, DialogContent } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { NativeSelect } from "@/components/ui/native-select";
import { Textarea } from "@/components/ui/textarea";
import {
  occupancy,
  loadHotelFromStorage,
  persistHotel,
  salesToday,
  useHotel,
  type CartItem,
  type Product,
  type ProductCategory,
  type Reservation,
  type Room,
  type RoomStatus,
  type RoomType,
} from "@/lib/hotel-store";
import { cn, formatDate, formatDateTime, money, todayISO, addDaysISO } from "@/lib/utils";

type Tab =
  | "tablero"
  | "habitaciones"
  | "reservas"
  | "recepcion"
  | "tienda"
  | "vender"
  | "cuentas"
  | "historial";

const TABS: { id: Tab; label: string; icon: typeof LayoutGrid }[] = [
  { id: "tablero", label: "Tablero", icon: LayoutGrid },
  { id: "habitaciones", label: "Habitaciones", icon: BedDouble },
  { id: "reservas", label: "Reservas", icon: CalendarCheck },
  { id: "recepcion", label: "Recepción", icon: KeyRound },
  { id: "tienda", label: "Tienda", icon: Store },
  { id: "vender", label: "Vender", icon: ShoppingBasket },
  { id: "cuentas", label: "Cuentas", icon: Receipt },
  { id: "historial", label: "Historial", icon: History },
];

const STATUS_BADGE: Record<RoomStatus, "available" | "occupied" | "cleaning" | "maintenance"> = {
  disponible: "available",
  ocupada: "occupied",
  limpieza: "cleaning",
  mantenimiento: "maintenance",
};

export function HotelApp() {
  const [tab, setTab] = useState<Tab>("tablero");

  useEffect(() => {
    loadHotelFromStorage();
    return useHotel.subscribe(() => persistHotel());
  }, []);

  return (
    <div className="min-h-dvh bg-bg text-fg">
      <Toaster position="bottom-right" richColors={false} />
      <header className="sticky top-0 z-20 border-b border-border bg-card/95 backdrop-blur">
        <div className="mx-auto flex max-w-6xl flex-wrap items-center justify-between gap-3 px-4 py-3">
          <div className="flex items-center gap-3">
            <div className="flex size-10 items-center justify-center rounded-lg bg-primary text-primary-foreground">
              <BedDouble className="size-5" />
            </div>
            <div>
              <p className="font-display text-lg leading-tight font-medium tracking-tight">Posada Tyt</p>
              <p className="text-xs text-muted-foreground">Recepción · habitaciones · tienda</p>
            </div>
          </div>
          <BackupButtons />
        </div>
        <nav className="mx-auto max-w-6xl overflow-x-auto px-2 pb-2">
          <div className="flex min-w-max gap-1">
            {TABS.map((t) => {
              const Icon = t.icon;
              const active = tab === t.id;
              return (
                <button
                  key={t.id}
                  type="button"
                  onClick={() => setTab(t.id)}
                  className={cn(
                    "inline-flex h-11 items-center gap-2 rounded-lg px-3 text-sm font-medium whitespace-nowrap transition-colors duration-150",
                    active
                      ? "bg-primary text-primary-foreground"
                      : "text-muted-foreground hover:bg-muted hover:text-fg",
                  )}
                >
                  <Icon className="size-4" />
                  {t.label}
                </button>
              );
            })}
          </div>
        </nav>
      </header>

      <main className="mx-auto max-w-6xl px-4 py-6">
        {tab === "tablero" && <Dashboard onGo={setTab} />}
        {tab === "habitaciones" && <RoomsView />}
        {tab === "reservas" && <ReservationsView />}
        {tab === "recepcion" && <FrontDeskView />}
        {tab === "tienda" && <ShopView />}
        {tab === "vender" && <PosView />}
        {tab === "cuentas" && <FoliosView />}
        {tab === "historial" && <HistoryView />}
      </main>
    </div>
  );
}

function BackupButtons() {
  const exportJson = useHotel((s) => s.exportJson);
  const importJson = useHotel((s) => s.importJson);

  function onExport() {
    const blob = new Blob([exportJson()], { type: "application/json" });
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = `posada-tyt-${todayISO()}.json`;
    a.click();
    toast.success("Copia descargada");
  }

  function onImport() {
    const input = document.createElement("input");
    input.type = "file";
    input.accept = "application/json";
    input.onchange = () => {
      const file = input.files?.[0];
      if (!file) return;
      const reader = new FileReader();
      reader.onload = () => {
        const err = importJson(String(reader.result ?? ""));
        if (err) toast.error(err);
        else toast.success("Datos restaurados");
      };
      reader.readAsText(file);
    };
    input.click();
  }

  return (
    <div className="flex gap-2">
      <Button variant="outline" size="sm" onClick={onExport}>
        <Download /> Exportar
      </Button>
      <Button variant="outline" size="sm" onClick={onImport}>
        <Upload /> Importar
      </Button>
    </div>
  );
}

function Dashboard({ onGo }: { onGo: (t: Tab) => void }) {
  const rooms = useHotel((s) => s.rooms);
  const reservations = useHotel((s) => s.reservations);
  const folios = useHotel((s) => s.folios);
  const sales = useHotel((s) => s.sales);
  const occ = occupancy(rooms);
  const hoy = todayISO();
  const ci = reservations.filter((r) => r.estado === "confirmada" && r.entrada === hoy).length;
  const co = folios.filter((f) => f.salidaPrevista === hoy).length;

  const movements = [
    ...reservations
      .filter((r) => r.estado === "confirmada" && (r.entrada === hoy || r.salida === hoy))
      .map((r) => ({
        id: r.id,
        tipo: r.entrada === hoy ? "Check-in" : "Salida prevista",
        nombre: r.nombre,
        hab: r.habNumero,
      })),
    ...folios
      .filter((f) => f.salidaPrevista === hoy)
      .map((f) => ({ id: f.id, tipo: "Check-out hoy", nombre: f.huesped, hab: f.habNumero })),
  ];

  return (
    <div className="space-y-6">
      <div>
        <h1 className="font-display text-3xl tracking-tight">Tablero</h1>
        <p className="mt-1 text-sm text-muted-foreground">Ocupación y movimiento del día.</p>
      </div>
      <div className="grid grid-cols-2 gap-3 md:grid-cols-3 lg:grid-cols-6">
        <Kpi label="Disponibles" value={occ.disponible} />
        <Kpi label="Ocupadas" value={occ.ocupada} />
        <Kpi label="Limpieza" value={occ.limpieza} />
        <Kpi label="Check-in hoy" value={ci} />
        <Kpi label="Check-out hoy" value={co} />
        <Kpi label="Ventas hoy" value={money(salesToday(sales))} wide />
      </div>
      <div className="grid gap-4 lg:grid-cols-2">
        <Card>
          <CardContent>
            <div className="mb-3 flex items-center justify-between">
              <h2 className="font-display text-base">Habitaciones</h2>
              <Button variant="ghost" size="sm" onClick={() => onGo("habitaciones")}>
                Ver todas
              </Button>
            </div>
            <div className="grid grid-cols-3 gap-2 sm:grid-cols-4">
              {[...rooms]
                .sort((a, b) => a.numero.localeCompare(b.numero, undefined, { numeric: true }))
                .map((r) => (
                  <div
                    key={r.id}
                    className={cn(
                      "rounded-lg border border-border p-3",
                      r.estado === "disponible" && "border-l-4 border-l-ok",
                      r.estado === "ocupada" && "border-l-4 border-l-danger",
                      r.estado === "limpieza" && "border-l-4 border-l-warn",
                    )}
                  >
                    <p className="font-display text-lg leading-none">{r.numero}</p>
                    <p className="mt-1 text-xs text-muted-foreground">{r.tipo}</p>
                    <p className="mt-2 text-[11px] tracking-wide uppercase">{r.estado}</p>
                  </div>
                ))}
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent>
            <h2 className="font-display mb-3 text-base">Hoy</h2>
            {movements.length === 0 ? (
              <p className="text-sm text-muted-foreground">Sin llegadas ni salidas programadas.</p>
            ) : (
              <ul className="space-y-2">
                {movements.map((m) => (
                  <li
                    key={m.id + m.tipo}
                    className="flex items-center justify-between rounded-lg bg-muted px-3 py-2 text-sm"
                  >
                    <span>
                      <span className="font-medium">{m.tipo}</span>
                      <span className="text-muted-foreground"> · {m.nombre}</span>
                    </span>
                    <span className="tabular text-muted-foreground">Hab {m.hab}</span>
                  </li>
                ))}
              </ul>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

function Kpi({ label, value, wide }: { label: string; value: string | number; wide?: boolean }) {
  return (
    <Card>
      <CardContent className={cn("py-4", wide && "col-span-2 sm:col-span-1")}>
        <p className="text-xs text-muted-foreground">{label}</p>
        <p className="font-display mt-1 text-2xl tabular tracking-tight">{value}</p>
      </CardContent>
    </Card>
  );
}

function RoomsView() {
  const rooms = useHotel((s) => s.rooms);
  const folios = useHotel((s) => s.folios);
  const upsertRoom = useHotel((s) => s.upsertRoom);
  const deleteRoom = useHotel((s) => s.deleteRoom);
  const setRoomStatus = useHotel((s) => s.setRoomStatus);
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState<Room | null>(null);

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="font-display text-3xl tracking-tight">Habitaciones</h1>
          <p className="mt-1 text-sm text-muted-foreground">Estados, tipos y tarifa por noche.</p>
        </div>
        <Button
          onClick={() => {
            setEditing(null);
            setOpen(true);
          }}
        >
          <Plus /> Nueva
        </Button>
      </div>
      <Card>
        <div className="overflow-x-auto">
          <table className="w-full min-w-[640px] text-sm">
            <thead className="border-b border-border bg-muted/60 text-left text-xs text-muted-foreground">
              <tr>
                <th className="px-4 py-3 font-medium">Nº</th>
                <th className="px-4 py-3 font-medium">Tipo</th>
                <th className="px-4 py-3 font-medium">Estado</th>
                <th className="px-4 py-3 text-right font-medium">Precio</th>
                <th className="px-4 py-3 font-medium">Huésped</th>
                <th className="px-4 py-3 text-right font-medium"> </th>
              </tr>
            </thead>
            <tbody>
              {[...rooms]
                .sort((a, b) => a.numero.localeCompare(b.numero, undefined, { numeric: true }))
                .map((r) => {
                  const folio = folios.find((f) => f.habId === r.id);
                  return (
                    <tr key={r.id} className="border-b border-border last:border-0">
                      <td className="px-4 py-3 font-medium">{r.numero}</td>
                      <td className="px-4 py-3">{r.tipo}</td>
                      <td className="px-4 py-3">
                        <Badge variant={STATUS_BADGE[r.estado]}>{r.estado}</Badge>
                      </td>
                      <td className="px-4 py-3 text-right tabular">{money(r.precio)}</td>
                      <td className="px-4 py-3">{folio?.huesped ?? "—"}</td>
                      <td className="px-4 py-3 text-right">
                        <div className="inline-flex gap-1">
                          {r.estado === "limpieza" && (
                            <Button size="sm" variant="ghost" onClick={() => setRoomStatus(r.id, "disponible")}>
                              Disponible
                            </Button>
                          )}
                          <Button
                            size="sm"
                            variant="ghost"
                            onClick={() => {
                              setEditing(r);
                              setOpen(true);
                            }}
                          >
                            Editar
                          </Button>
                          <Button
                            size="icon"
                            variant="ghost"
                            onClick={() => {
                              const err = deleteRoom(r.id);
                              if (err) toast.error(err);
                            }}
                          >
                            <Trash2 />
                          </Button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
            </tbody>
          </table>
        </div>
      </Card>
      <RoomDialog open={open} onOpenChange={setOpen} room={editing} onSave={upsertRoom} />
    </div>
  );
}

function RoomDialog({
  open,
  onOpenChange,
  room,
  onSave,
}: {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  room: Room | null;
  onSave: (r: Omit<Room, "id"> & { id?: string }) => void;
}) {
  const [numero, setNumero] = useState("");
  const [tipo, setTipo] = useState<RoomType>("Individual");
  const [precio, setPrecio] = useState("0");
  const [estado, setEstado] = useState<RoomStatus>("disponible");

  useEffect(() => {
    if (open) {
      setNumero(room?.numero ?? "");
      setTipo(room?.tipo ?? "Individual");
      setPrecio(String(room?.precio ?? 0));
      setEstado(room?.estado ?? "disponible");
    }
  }, [open, room]);

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent title={room ? "Editar habitación" : "Nueva habitación"}>
        <form
          className="space-y-3"
          onSubmit={(e) => {
            e.preventDefault();
            onSave({
              id: room?.id,
              numero: numero.trim(),
              tipo,
              precio: Number(precio) || 0,
              estado,
            });
            onOpenChange(false);
            toast.success("Habitación guardada");
          }}
        >
          <Field label="Número">
            <Input required value={numero} onChange={(e) => setNumero(e.target.value)} />
          </Field>
          <div className="grid grid-cols-2 gap-3">
            <Field label="Tipo">
              <NativeSelect value={tipo} onChange={(e) => setTipo(e.target.value as RoomType)}>
                {["Individual", "Doble", "Matrimonial", "Suite", "Familiar"].map((t) => (
                  <option key={t}>{t}</option>
                ))}
              </NativeSelect>
            </Field>
            <Field label="Precio / noche">
              <Input type="number" min="0" step="0.01" value={precio} onChange={(e) => setPrecio(e.target.value)} />
            </Field>
          </div>
          <Field label="Estado">
            <NativeSelect value={estado} onChange={(e) => setEstado(e.target.value as RoomStatus)}>
              {["disponible", "ocupada", "limpieza", "mantenimiento"].map((t) => (
                <option key={t} value={t}>
                  {t}
                </option>
              ))}
            </NativeSelect>
          </Field>
          <div className="flex justify-end gap-2 pt-2">
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
              Cancelar
            </Button>
            <Button type="submit">Guardar</Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}

function Field({ label, children }: { label: string; children: ReactNode }) {
  return (
    <div className="space-y-1.5">
      <Label>{label}</Label>
      {children}
    </div>
  );
}

function ReservationsView() {
  const reservations = useHotel((s) => s.reservations);
  const rooms = useHotel((s) => s.rooms);
  const addReservation = useHotel((s) => s.addReservation);
  const cancelReservation = useHotel((s) => s.cancelReservation);
  const [open, setOpen] = useState(false);

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="font-display text-3xl tracking-tight">Reservas</h1>
          <p className="mt-1 text-sm text-muted-foreground">Llegadas confirmadas y cancelaciones.</p>
        </div>
        <Button onClick={() => setOpen(true)}>
          <Plus /> Nueva reserva
        </Button>
      </div>
      <Card>
        <div className="overflow-x-auto">
          <table className="w-full min-w-[720px] text-sm">
            <thead className="border-b border-border bg-muted/60 text-left text-xs text-muted-foreground">
              <tr>
                <th className="px-4 py-3 font-medium">Huésped</th>
                <th className="px-4 py-3 font-medium">Habitación</th>
                <th className="px-4 py-3 font-medium">Entrada</th>
                <th className="px-4 py-3 font-medium">Salida</th>
                <th className="px-4 py-3 font-medium">Estado</th>
                <th className="px-4 py-3" />
              </tr>
            </thead>
            <tbody>
              {reservations.length === 0 ? (
                <tr>
                  <td colSpan={6} className="px-4 py-10 text-center text-muted-foreground">
                    Aún no hay reservas.
                  </td>
                </tr>
              ) : (
                [...reservations]
                  .sort((a, b) => a.entrada.localeCompare(b.entrada))
                  .map((r) => (
                    <tr key={r.id} className="border-b border-border last:border-0">
                      <td className="px-4 py-3">
                        <div className="font-medium">{r.nombre}</div>
                        <div className="text-xs text-muted-foreground">
                          {r.tel}
                          {r.doc ? ` · ${r.doc}` : ""}
                        </div>
                      </td>
                      <td className="px-4 py-3">Hab {r.habNumero}</td>
                      <td className="px-4 py-3">{formatDate(r.entrada)}</td>
                      <td className="px-4 py-3">{formatDate(r.salida)}</td>
                      <td className="px-4 py-3">
                        <Badge variant={r.estado === "confirmada" ? "info" : r.estado === "checkin" ? "available" : "default"}>
                          {r.estado}
                        </Badge>
                      </td>
                      <td className="px-4 py-3 text-right">
                        {r.estado === "confirmada" && (
                          <Button size="sm" variant="ghost" onClick={() => cancelReservation(r.id)}>
                            Cancelar
                          </Button>
                        )}
                      </td>
                    </tr>
                  ))
              )}
            </tbody>
          </table>
        </div>
      </Card>
      <ReservationDialog open={open} onOpenChange={setOpen} rooms={rooms} onSave={addReservation} />
    </div>
  );
}

function ReservationDialog({
  open,
  onOpenChange,
  rooms,
  onSave,
}: {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  rooms: Room[];
  onSave: (d: {
    nombre: string;
    tel: string;
    doc: string;
    habId: string;
    entrada: string;
    salida: string;
    notas: string;
  }) => string | null;
}) {
  const [nombre, setNombre] = useState("");
  const [tel, setTel] = useState("");
  const [doc, setDoc] = useState("");
  const [habId, setHabId] = useState("");
  const [entrada, setEntrada] = useState(todayISO());
  const [salida, setSalida] = useState(addDaysISO(todayISO(), 1));
  const [notas, setNotas] = useState("");

  useEffect(() => {
    if (open) {
      setNombre("");
      setTel("");
      setDoc("");
      setHabId(rooms[0]?.id ?? "");
      setEntrada(todayISO());
      setSalida(addDaysISO(todayISO(), 1));
      setNotas("");
    }
  }, [open, rooms]);

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent title="Nueva reserva">
        <form
          className="space-y-3"
          onSubmit={(e) => {
            e.preventDefault();
            const err = onSave({ nombre, tel, doc, habId, entrada, salida, notas });
            if (err) {
              toast.error(err);
              return;
            }
            onOpenChange(false);
            toast.success("Reserva creada");
          }}
        >
          <Field label="Huésped">
            <Input required value={nombre} onChange={(e) => setNombre(e.target.value)} />
          </Field>
          <div className="grid grid-cols-2 gap-3">
            <Field label="Teléfono">
              <Input value={tel} onChange={(e) => setTel(e.target.value)} />
            </Field>
            <Field label="Documento">
              <Input value={doc} onChange={(e) => setDoc(e.target.value)} />
            </Field>
          </div>
          <Field label="Habitación">
            <NativeSelect value={habId} onChange={(e) => setHabId(e.target.value)} required>
              {rooms.map((h) => (
                <option key={h.id} value={h.id}>
                  {h.numero} · {h.tipo} · {money(h.precio)}
                </option>
              ))}
            </NativeSelect>
          </Field>
          <div className="grid grid-cols-2 gap-3">
            <Field label="Entrada">
              <Input id="res-entrada" type="date" required value={entrada} onChange={(e) => setEntrada(e.target.value)} />
            </Field>
            <Field label="Salida">
              <Input id="res-salida" type="date" required value={salida} onChange={(e) => setSalida(e.target.value)} />
            </Field>
          </div>
          <Field label="Notas">
            <Textarea value={notas} onChange={(e) => setNotas(e.target.value)} rows={2} />
          </Field>
          <div className="flex justify-end gap-2 pt-2">
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
              Cancelar
            </Button>
            <Button type="submit">Guardar</Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}

function FrontDeskView() {
  const reservations = useHotel((s) => s.reservations);
  const rooms = useHotel((s) => s.rooms);
  const folios = useHotel((s) => s.folios);
  const checkIn = useHotel((s) => s.checkIn);
  const checkOut = useHotel((s) => s.checkOut);
  const [resId, setResId] = useState("");
  const [folioId, setFolioId] = useState("");

  const confirmadas = reservations.filter((r) => r.estado === "confirmada");
  const reserva: Reservation | undefined = confirmadas.find((r) => r.id === resId);
  const hab = rooms.find((h) => h.id === reserva?.habId);
  const folio = folios.find((f) => f.id === folioId);

  return (
    <div className="space-y-4">
      <div>
        <h1 className="font-display text-3xl tracking-tight">Recepción</h1>
        <p className="mt-1 text-sm text-muted-foreground">Check-in, check-out y cobro de la cuenta.</p>
      </div>
      <div className="grid gap-4 lg:grid-cols-2">
        <Card>
          <CardContent className="space-y-3">
            <h2 className="font-display text-base">Check-in</h2>
            <Field label="Reserva confirmada">
              <NativeSelect value={resId} onChange={(e) => setResId(e.target.value)}>
                <option value="">Elegir reserva</option>
                {confirmadas.map((r) => (
                  <option key={r.id} value={r.id}>
                    {r.nombre} · Hab {r.habNumero} · {formatDate(r.entrada)}
                  </option>
                ))}
              </NativeSelect>
            </Field>
            {reserva && (
              <div className="rounded-lg bg-ok-soft p-3 text-sm text-ok">
                <p className="font-medium">{reserva.nombre}</p>
                <p>
                  Hab {reserva.habNumero}
                  {hab ? ` · ${hab.tipo}` : ""}
                </p>
                <p>
                  {formatDate(reserva.entrada)} → {formatDate(reserva.salida)}
                </p>
                {hab && hab.estado !== "disponible" && (
                  <p className="mt-1 font-medium text-danger">La habitación no está disponible.</p>
                )}
              </div>
            )}
            <Button
              className="w-full"
              disabled={!reserva || hab?.estado !== "disponible"}
              onClick={() => {
                const err = checkIn(resId);
                if (err) toast.error(err);
                else {
                  toast.success(`Check-in: Hab ${reserva?.habNumero}`);
                  setResId("");
                }
              }}
            >
              Confirmar check-in
            </Button>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="space-y-3">
            <h2 className="font-display text-base">Check-out</h2>
            <Field label="Habitación ocupada">
              <NativeSelect value={folioId} onChange={(e) => setFolioId(e.target.value)}>
                <option value="">Elegir habitación</option>
                {folios.map((f) => (
                  <option key={f.id} value={f.id}>
                    Hab {f.habNumero} · {f.huesped}
                  </option>
                ))}
              </NativeSelect>
            </Field>
            {folio && (
              <div className="space-y-2 rounded-lg bg-danger-soft p-3 text-sm">
                <p className="font-medium">
                  {folio.huesped} · Hab {folio.habNumero}
                </p>
                {folio.cargos.map((c) => (
                  <div key={c.id} className="flex justify-between text-xs">
                    <span>
                      {c.concepto} ×{c.cantidad}
                    </span>
                    <span className="tabular">{money(c.total)}</span>
                  </div>
                ))}
                <p className="font-display text-right text-lg">{money(folio.total)}</p>
              </div>
            )}
            <Button
              className="w-full"
              variant="destructive"
              disabled={!folio}
              onClick={() => {
                if (!folio) return;
                const err = checkOut(folio.id);
                if (err) toast.error(err);
                else {
                  toast.success(`Check-out cobrado: ${money(folio.total)}`);
                  setFolioId("");
                }
              }}
            >
              Cobrar y hacer check-out
            </Button>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

function ShopView() {
  const products = useHotel((s) => s.products);
  const upsertProduct = useHotel((s) => s.upsertProduct);
  const deleteProduct = useHotel((s) => s.deleteProduct);
  const [cat, setCat] = useState<ProductCategory | "">("");
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState<Product | null>(null);
  const list = cat ? products.filter((p) => p.categoria === cat) : products;

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="font-display text-3xl tracking-tight">Tienda</h1>
          <p className="mt-1 text-sm text-muted-foreground">Snacks, aseo y lavandería.</p>
        </div>
        <Button
          onClick={() => {
            setEditing(null);
            setOpen(true);
          }}
        >
          <Plus /> Nuevo ítem
        </Button>
      </div>
      <div className="flex flex-wrap gap-2">
        {(["", "Snack", "Aseo", "Lavandería", "Otro"] as const).map((c) => (
          <button
            key={c || "all"}
            type="button"
            onClick={() => setCat(c)}
            className={cn(
              "h-10 rounded-full px-3 text-sm",
              cat === c ? "bg-primary text-primary-foreground" : "bg-muted text-muted-foreground",
            )}
          >
            {c || "Todos"}
          </button>
        ))}
      </div>
      <Card>
        <div className="overflow-x-auto">
          <table className="w-full min-w-[560px] text-sm">
            <thead className="border-b border-border bg-muted/60 text-left text-xs text-muted-foreground">
              <tr>
                <th className="px-4 py-3 font-medium">Nombre</th>
                <th className="px-4 py-3 font-medium">Categoría</th>
                <th className="px-4 py-3 text-right font-medium">Stock</th>
                <th className="px-4 py-3 text-right font-medium">Precio</th>
                <th className="px-4 py-3" />
              </tr>
            </thead>
            <tbody>
              {list.map((p) => (
                <tr key={p.id} className="border-b border-border last:border-0">
                  <td className="px-4 py-3 font-medium">{p.nombre}</td>
                  <td className="px-4 py-3">
                    <Badge>{p.categoria}</Badge>
                  </td>
                  <td className="px-4 py-3 text-right tabular">{p.tipo === "servicio" ? "—" : p.stock}</td>
                  <td className="px-4 py-3 text-right tabular">{money(p.precio)}</td>
                  <td className="px-4 py-3 text-right">
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => {
                        setEditing(p);
                        setOpen(true);
                      }}
                    >
                      Editar
                    </Button>
                    <Button size="icon" variant="ghost" onClick={() => deleteProduct(p.id)}>
                      <Trash2 />
                    </Button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>
      <ProductDialog open={open} onOpenChange={setOpen} product={editing} onSave={upsertProduct} />
    </div>
  );
}

function ProductDialog({
  open,
  onOpenChange,
  product,
  onSave,
}: {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  product: Product | null;
  onSave: (p: Omit<Product, "id"> & { id?: string }) => void;
}) {
  const [nombre, setNombre] = useState("");
  const [categoria, setCategoria] = useState<ProductCategory>("Snack");
  const [tipo, setTipo] = useState<Product["tipo"]>("producto");
  const [stock, setStock] = useState("0");
  const [precio, setPrecio] = useState("0");

  useEffect(() => {
    if (open) {
      setNombre(product?.nombre ?? "");
      setCategoria(product?.categoria ?? "Snack");
      setTipo(product?.tipo ?? "producto");
      setStock(String(product?.stock ?? 0));
      setPrecio(String(product?.precio ?? 0));
    }
  }, [open, product]);

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent title={product ? "Editar ítem" : "Nuevo producto o servicio"}>
        <form
          className="space-y-3"
          onSubmit={(e) => {
            e.preventDefault();
            onSave({
              id: product?.id,
              nombre: nombre.trim(),
              categoria,
              tipo,
              stock: Number(stock) || 0,
              precio: Number(precio) || 0,
            });
            onOpenChange(false);
            toast.success("Guardado");
          }}
        >
          <Field label="Nombre">
            <Input required value={nombre} onChange={(e) => setNombre(e.target.value)} />
          </Field>
          <div className="grid grid-cols-2 gap-3">
            <Field label="Categoría">
              <NativeSelect value={categoria} onChange={(e) => setCategoria(e.target.value as ProductCategory)}>
                {["Snack", "Aseo", "Lavandería", "Otro"].map((c) => (
                  <option key={c}>{c}</option>
                ))}
              </NativeSelect>
            </Field>
            <Field label="Tipo">
              <NativeSelect value={tipo} onChange={(e) => setTipo(e.target.value as Product["tipo"])}>
                <option value="producto">Producto (stock)</option>
                <option value="servicio">Servicio</option>
              </NativeSelect>
            </Field>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <Field label="Stock">
              <Input type="number" min="0" value={stock} onChange={(e) => setStock(e.target.value)} />
            </Field>
            <Field label="Precio">
              <Input type="number" min="0" step="0.01" value={precio} onChange={(e) => setPrecio(e.target.value)} />
            </Field>
          </div>
          <div className="flex justify-end gap-2 pt-2">
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
              Cancelar
            </Button>
            <Button type="submit">Guardar</Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}

function PosView() {
  const products = useHotel((s) => s.products);
  const folios = useHotel((s) => s.folios);
  const sell = useHotel((s) => s.sell);
  const [q, setQ] = useState("");
  const [cart, setCart] = useState<CartItem[]>([]);
  const [descuento, setDescuento] = useState("0");
  const [destino, setDestino] = useState<"caja" | "habitacion">("caja");
  const [folioId, setFolioId] = useState(folios[0]?.id ?? "");
  const [metodo, setMetodo] = useState("Efectivo");

  const results = useMemo(() => {
    const n = q.toLowerCase();
    if (!n) return [];
    return products
      .filter(
        (p) =>
          p.nombre.toLowerCase().includes(n) && (p.tipo === "servicio" || p.stock > 0),
      )
      .slice(0, 8);
  }, [q, products]);

  const sub = cart.reduce((s, i) => s + i.precio * i.cantidad, 0);
  const total = Math.max(0, sub - (Number(descuento) || 0));

  function add(p: Product) {
    setCart((prev) => {
      const exist = prev.find((i) => i.id === p.id);
      if (exist) {
        if (p.tipo === "producto" && exist.cantidad >= p.stock) {
          toast.error("Sin stock");
          return prev;
        }
        return prev.map((i) => (i.id === p.id ? { ...i, cantidad: i.cantidad + 1 } : i));
      }
      return [
        ...prev,
        { id: p.id, nombre: p.nombre, precio: p.precio, cantidad: 1, tipo: p.tipo, stockDisp: p.stock },
      ];
    });
    setQ("");
  }

  return (
    <div className="space-y-4">
      <div>
        <h1 className="font-display text-3xl tracking-tight">Vender</h1>
        <p className="mt-1 text-sm text-muted-foreground">Cobra en caja o carga a la habitación.</p>
      </div>
      <div className="grid gap-4 lg:grid-cols-3">
        <Card className="lg:col-span-2">
          <CardContent>
            <div className="relative mb-4">
              <Search className="pointer-events-none absolute top-1/2 left-3 size-4 -translate-y-1/2 text-muted-foreground" />
              <Input
                className="pl-10"
                placeholder="Buscar snack, aseo o lavandería…"
                value={q}
                onChange={(e) => setQ(e.target.value)}
              />
              {results.length > 0 && (
                <div className="absolute z-10 mt-1 w-full overflow-hidden rounded-lg border border-border bg-card shadow-sm">
                  {results.map((p) => (
                    <button
                      key={p.id}
                      type="button"
                      className="flex w-full items-center justify-between px-3 py-2.5 text-left text-sm hover:bg-muted"
                      onClick={() => add(p)}
                    >
                      <span>
                        {p.nombre}
                        <span className="ml-2 text-xs text-muted-foreground">{p.categoria}</span>
                      </span>
                      <span className="tabular">{money(p.precio)}</span>
                    </button>
                  ))}
                </div>
              )}
            </div>
            {cart.length === 0 ? (
              <p className="py-10 text-center text-sm text-muted-foreground">Agrega productos o servicios.</p>
            ) : (
              <table className="w-full text-sm">
                <tbody>
                  {cart.map((i) => (
                    <tr key={i.id} className="border-b border-border last:border-0">
                      <td className="py-2 font-medium">{i.nombre}</td>
                      <td className="py-2 text-center">
                        <button
                          type="button"
                          className="size-8 rounded-md bg-muted"
                          onClick={() =>
                            setCart((c) =>
                              c
                                .map((x) => (x.id === i.id ? { ...x, cantidad: x.cantidad - 1 } : x))
                                .filter((x) => x.cantidad > 0),
                            )
                          }
                        >
                          −
                        </button>
                        <span className="mx-2 tabular">{i.cantidad}</span>
                        <button
                          type="button"
                          className="size-8 rounded-md bg-muted"
                          onClick={() => {
                            const p = products.find((x) => x.id === i.id);
                            if (p) add(p);
                          }}
                        >
                          +
                        </button>
                      </td>
                      <td className="py-2 text-right tabular">{money(i.precio * i.cantidad)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            )}
          </CardContent>
        </Card>
        <Card>
          <CardContent className="space-y-3">
            <h2 className="font-display text-base">Resumen</h2>
            <div className="flex justify-between text-sm">
              <span className="text-muted-foreground">Subtotal</span>
              <span className="tabular">{money(sub)}</span>
            </div>
            <Field label="Descuento">
              <Input type="number" min="0" step="0.01" value={descuento} onChange={(e) => setDescuento(e.target.value)} />
            </Field>
            <div className="flex justify-between border-t border-border pt-3">
              <span className="font-medium">Total</span>
              <span className="font-display text-xl tabular">{money(total)}</span>
            </div>
            <Field label="Cobrar a">
              <NativeSelect
                value={destino}
                onChange={(e) => setDestino(e.target.value as "caja" | "habitacion")}
              >
                <option value="caja">Caja</option>
                <option value="habitacion">Habitación</option>
              </NativeSelect>
            </Field>
            {destino === "habitacion" ? (
              <Field label="Habitación">
                <NativeSelect value={folioId} onChange={(e) => setFolioId(e.target.value)}>
                  {folios.length === 0 && <option value="">Sin ocupadas</option>}
                  {folios.map((f) => (
                    <option key={f.id} value={f.id}>
                      Hab {f.habNumero} · {f.huesped}
                    </option>
                  ))}
                </NativeSelect>
              </Field>
            ) : (
              <Field label="Pago">
                <NativeSelect value={metodo} onChange={(e) => setMetodo(e.target.value)}>
                  <option>Efectivo</option>
                  <option>Tarjeta</option>
                  <option>Transferencia</option>
                </NativeSelect>
              </Field>
            )}
            <Button
              className="w-full"
              disabled={!cart.length}
              onClick={() => {
                const msg = sell({
                  items: cart,
                  descuento: Number(descuento) || 0,
                  destino,
                  folioId,
                  metodo,
                });
                if (!msg) return;
                if (msg.startsWith("Sin") || msg.startsWith("Selecciona") || msg.startsWith("Agrega")) {
                  toast.error(msg);
                  return;
                }
                toast.success(msg);
                setCart([]);
                setDescuento("0");
              }}
            >
              Confirmar
            </Button>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

function FoliosView() {
  const folios = useHotel((s) => s.folios);
  return (
    <div className="space-y-4">
      <div>
        <h1 className="font-display text-3xl tracking-tight">Cuentas abiertas</h1>
        <p className="mt-1 text-sm text-muted-foreground">Alojamiento, snacks, aseo y lavadas cargados.</p>
      </div>
      {folios.length === 0 ? (
        <p className="py-12 text-center text-sm text-muted-foreground">No hay habitaciones ocupadas.</p>
      ) : (
        <div className="grid gap-4 md:grid-cols-2">
          {folios.map((f) => (
            <Card key={f.id}>
              <CardContent>
                <div className="flex items-start justify-between">
                  <div>
                    <p className="font-display text-xl">Hab {f.habNumero}</p>
                    <p className="text-sm text-muted-foreground">{f.huesped}</p>
                    <p className="text-xs text-muted-foreground">
                      {formatDate(f.entrada)} → {formatDate(f.salidaPrevista)}
                    </p>
                  </div>
                  <p className="font-display text-xl tabular">{money(f.total)}</p>
                </div>
                <ul className="mt-3 space-y-1 border-t border-border pt-3 text-xs">
                  {f.cargos.map((c) => (
                    <li key={c.id} className="flex justify-between">
                      <span>
                        {c.concepto} ×{c.cantidad}
                      </span>
                      <span className="tabular">{money(c.total)}</span>
                    </li>
                  ))}
                </ul>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}

function HistoryView() {
  const sales = useHotel((s) => s.sales);
  const list = [...sales].sort((a, b) => b.fecha.localeCompare(a.fecha));
  return (
    <div className="space-y-4">
      <div>
        <h1 className="font-display text-3xl tracking-tight">Historial</h1>
        <p className="mt-1 text-sm text-muted-foreground">Ventas de mostrador y check-outs cobrados.</p>
      </div>
      <Card>
        <div className="overflow-x-auto">
          <table className="w-full min-w-[640px] text-sm">
            <thead className="border-b border-border bg-muted/60 text-left text-xs text-muted-foreground">
              <tr>
                <th className="px-4 py-3 font-medium">Fecha</th>
                <th className="px-4 py-3 font-medium">Tipo</th>
                <th className="px-4 py-3 font-medium">Detalle</th>
                <th className="px-4 py-3 text-right font-medium">Total</th>
              </tr>
            </thead>
            <tbody>
              {list.length === 0 ? (
                <tr>
                  <td colSpan={4} className="px-4 py-10 text-center text-muted-foreground">
                    Sin movimientos.
                  </td>
                </tr>
              ) : (
                list.map((v) => (
                  <tr key={v.id} className="border-b border-border last:border-0">
                    <td className="px-4 py-3">{formatDateTime(v.fecha)}</td>
                    <td className="px-4 py-3">
                      <Badge variant={v.tipo === "checkout" ? "info" : "available"}>
                        {v.tipo === "checkout" ? "Check-out" : "Venta"}
                      </Badge>
                    </td>
                    <td className="max-w-xs truncate px-4 py-3">{v.detalle}</td>
                    <td className="px-4 py-3 text-right tabular font-medium">{money(v.total)}</td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </Card>
    </div>
  );
}

