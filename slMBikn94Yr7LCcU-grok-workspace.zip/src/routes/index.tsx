import { createFileRoute } from "@tanstack/react-router";
import { HotelApp } from "@/components/hotel-app";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  return <HotelApp />;
}
