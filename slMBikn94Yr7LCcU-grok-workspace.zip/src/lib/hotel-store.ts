import { create } from "zustand";
import { money, nightsBetween, todayISO, uid } from "@/lib/utils";

export type RoomStatus = "disponible" | "ocupada" | "limpieza" | "mantenimiento";
export type RoomType = "Individual" | "Doble" | "Matrimonial" | "Suite" | "Familiar";
export type ReservationStatus = "confirmada" | "checkin" | "cancelada" | "completada";
export type ProductCategory = "Snack" | "Aseo" | "Lavandería" | "Otro";
export type ProductKind = "producto" | "servicio";

export type Room = {
  id: string;
  numero: string;
  tipo: RoomType;
  precio: number;
  estado: RoomStatus;
};

export type Reservation = {
  id: string;
  nombre: string;
  tel: string;
  doc: string;
  habId: string;
  habNumero: string;
  entrada: string;
  salida: string;
  notas: string;
  estado: ReservationStatus;
  precioNoche: number;
};

export type Product = {
  id: string;
  nombre: string;
  categoria: ProductCategory;
  tipo: ProductKind;
  stock: number;
  precio: number;
};

export type Charge = {
  id: string;
  concepto: string;
  cantidad: number;
  precio: number;
  total: number;
  fecha: string;
};

export type Folio = {
  id: string;
  reservaId: string;
  habId: string;
  habNumero: string;
  huesped: string;
  entrada: string;
  salidaPrevista: string;
  checkIn: string;
  precioNoche: number;
  noches: number;
  cargos: Charge[];
  total: number;
};

export type Sale = {
  id: string;
  fecha: string;
  tipo: "venta" | "checkout";
  detalle: string;
  items: Charge[];
  total: number;
  metodo: string;
};

export type CartItem = {
  id: string;
  nombre: string;
  precio: number;
  cantidad: number;
  tipo: ProductKind;
  stockDisp: number;
};

type HotelState = {
  rooms: Room[];
  reservations: Reservation[];
  products: Product[];
  sales: Sale[];
  folios: Folio[];
  hydrated: boolean;
  setHydrated: (v: boolean) => void;
  upsertRoom: (room: Omit<Room, "id"> & { id?: string }) => void;
  deleteRoom: (id: string) => string | null;
  setRoomStatus: (id: string, estado: RoomStatus) => void;
  addReservation: (data: {
    nombre: string;
    tel: string;
    doc: string;
    habId: string;
    entrada: string;
    salida: string;
    notas: string;
  }) => string | null;
  cancelReservation: (id: string) => void;
  checkIn: (reservationId: string) => string | null;
  checkOut: (folioId: string) => string | null;
  upsertProduct: (p: Omit<Product, "id"> & { id?: string }) => void;
  deleteProduct: (id: string) => void;
  sell: (input: {
    items: CartItem[];
    descuento: number;
    destino: "caja" | "habitacion";
    folioId?: string;
    metodo: string;
  }) => string | null;
  exportJson: () => string;
  importJson: (raw: string) => string | null;
};

function seedRooms(): Room[] {
  const mk = (id: string, numero: string, tipo: RoomType, precio: number, estado: RoomStatus): Room => ({
    id,
    numero,
    tipo,
    precio,
    estado,
  });
  return [
    mk("r101", "101", "Individual", 450, "disponible"),
    mk("r102", "102", "Doble", 650, "disponible"),
    mk("r103", "103", "Matrimonial", 700, "disponible"),
    mk("r201", "201", "Suite", 1200, "disponible"),
    mk("r202", "202", "Familiar", 950, "disponible"),
    mk("r203", "203", "Doble", 650, "limpieza"),
  ];
}

function seedProducts(): Product[] {
  const mk = (
    id: string,
    nombre: string,
    categoria: ProductCategory,
    tipo: ProductKind,
    stock: number,
    precio: number,
  ): Product => ({ id, nombre, categoria, tipo, stock, precio });
  return [
    mk("p1", "Agua mineral 500ml", "Snack", "producto", 48, 25),
    mk("p2", "Refresco 355ml", "Snack", "producto", 36, 30),
    mk("p3", "Papas fritas", "Snack", "producto", 24, 35),
    mk("p4", "Chocolate", "Snack", "producto", 20, 28),
    mk("p5", "Jabón de tocador", "Aseo", "producto", 40, 15),
    mk("p6", "Shampoo sobrecito", "Aseo", "producto", 50, 12),
    mk("p7", "Pasta dental", "Aseo", "producto", 30, 20),
    mk("p8", "Lavado de camisa", "Lavandería", "servicio", 0, 45),
    mk("p9", "Lavado de pantalón", "Lavandería", "servicio", 0, 55),
    mk("p10", "Lavado de vestido", "Lavandería", "servicio", 0, 80),
    mk("p11", "Planchado", "Lavandería", "servicio", 0, 30),
  ];
}

const STORAGE_KEY = "posada-tyt-v1";

export function loadHotelFromStorage() {
  if (typeof window === "undefined") return;
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return;
    const d = JSON.parse(raw) as Partial<{
      rooms: Room[];
      reservations: Reservation[];
      products: Product[];
      sales: Sale[];
      folios: Folio[];
    }>;
    useHotel.setState({
      rooms: d.rooms ?? useHotel.getState().rooms,
      reservations: d.reservations ?? [],
      products: d.products ?? useHotel.getState().products,
      sales: d.sales ?? [],
      folios: d.folios ?? [],
    });
  } catch {
    /* keep seed */
  }
}

export function persistHotel() {
  if (typeof window === "undefined") return;
  const s = useHotel.getState();
  localStorage.setItem(
    STORAGE_KEY,
    JSON.stringify({
      rooms: s.rooms,
      reservations: s.reservations,
      products: s.products,
      sales: s.sales,
      folios: s.folios,
    }),
  );
}

export const useHotel = create<HotelState>()((set, get) => ({
      rooms: seedRooms(),
      reservations: [],
      products: seedProducts(),
      sales: [],
      folios: [],
      hydrated: false,
      setHydrated: (v) => set({ hydrated: v }),

      upsertRoom: (room) => {
        set((s) => {
          if (room.id) {
            return {
              rooms: s.rooms.map((r) => (r.id === room.id ? { ...r, ...room, id: r.id } : r)),
            };
          }
          return {
            rooms: [...s.rooms, { ...room, id: uid() }],
          };
        });
      },

      deleteRoom: (id) => {
        const open = get().folios.some((f) => f.habId === id);
        if (open) return "No se puede eliminar: hay una cuenta abierta.";
        set((s) => ({ rooms: s.rooms.filter((r) => r.id !== id) }));
        return null;
      },

      setRoomStatus: (id, estado) => {
        set((s) => ({
          rooms: s.rooms.map((r) => (r.id === id ? { ...r, estado } : r)),
        }));
      },

      addReservation: (data) => {
        const hab = get().rooms.find((r) => r.id === data.habId);
        if (!hab) return "Selecciona una habitación.";
        if (data.salida <= data.entrada) return "La salida debe ser posterior a la entrada.";
        set((s) => ({
          reservations: [
            ...s.reservations,
            {
              id: uid(),
              nombre: data.nombre.trim(),
              tel: data.tel.trim(),
              doc: data.doc.trim(),
              habId: hab.id,
              habNumero: hab.numero,
              entrada: data.entrada,
              salida: data.salida,
              notas: data.notas.trim(),
              estado: "confirmada",
              precioNoche: hab.precio,
            },
          ],
        }));
        return null;
      },

      cancelReservation: (id) => {
        set((s) => ({
          reservations: s.reservations.map((r) =>
            r.id === id && r.estado === "confirmada" ? { ...r, estado: "cancelada" } : r,
          ),
        }));
      },

      checkIn: (reservationId) => {
        const r = get().reservations.find((x) => x.id === reservationId);
        if (!r || r.estado !== "confirmada") return "Reserva no válida.";
        const hab = get().rooms.find((h) => h.id === r.habId);
        if (!hab) return "Habitación no encontrada.";
        if (hab.estado !== "disponible") return "La habitación no está disponible.";
        const noches = nightsBetween(r.entrada, r.salida);
        const cargo: Charge = {
          id: uid(),
          concepto: `Alojamiento ${noches} noche(s)`,
          cantidad: noches,
          precio: r.precioNoche,
          total: noches * r.precioNoche,
          fecha: new Date().toISOString(),
        };
        set((s) => ({
          rooms: s.rooms.map((h) => (h.id === hab.id ? { ...h, estado: "ocupada" } : h)),
          reservations: s.reservations.map((x) =>
            x.id === r.id ? { ...x, estado: "checkin" } : x,
          ),
          folios: [
            ...s.folios,
            {
              id: uid(),
              reservaId: r.id,
              habId: r.habId,
              habNumero: r.habNumero,
              huesped: r.nombre,
              entrada: r.entrada,
              salidaPrevista: r.salida,
              checkIn: new Date().toISOString(),
              precioNoche: r.precioNoche,
              noches,
              cargos: [cargo],
              total: cargo.total,
            },
          ],
        }));
        return null;
      },

      checkOut: (folioId) => {
        const folio = get().folios.find((f) => f.id === folioId);
        if (!folio) return "Cuenta no encontrada.";
        const sale: Sale = {
          id: uid(),
          fecha: new Date().toISOString(),
          tipo: "checkout",
          detalle: `Check-out Hab ${folio.habNumero} · ${folio.huesped}`,
          items: folio.cargos,
          total: folio.total,
          metodo: "Check-out",
        };
        set((s) => ({
          sales: [...s.sales, sale],
          rooms: s.rooms.map((h) =>
            h.id === folio.habId ? { ...h, estado: "limpieza" } : h,
          ),
          reservations: s.reservations.map((r) =>
            r.id === folio.reservaId ? { ...r, estado: "completada" } : r,
          ),
          folios: s.folios.filter((f) => f.id !== folioId),
        }));
        return null;
      },

      upsertProduct: (p) => {
        set((s) => {
          if (p.id) {
            return {
              products: s.products.map((x) => (x.id === p.id ? { ...x, ...p, id: x.id } : x)),
            };
          }
          return { products: [...s.products, { ...p, id: uid() }] };
        });
      },

      deleteProduct: (id) => {
        set((s) => ({ products: s.products.filter((p) => p.id !== id) }));
      },

      sell: ({ items, descuento, destino, folioId, metodo }) => {
        if (!items.length) return "Agrega productos o servicios.";
        const products = get().products;
        for (const item of items) {
          if (item.tipo === "producto") {
            const p = products.find((x) => x.id === item.id);
            if (!p || p.stock < item.cantidad) return `Sin stock de ${item.nombre}.`;
          }
        }
        const sub = items.reduce((s, i) => s + i.precio * i.cantidad, 0);
        const total = Math.max(0, sub - (descuento || 0));
        const charges: Charge[] = items.map((i) => ({
          id: uid(),
          concepto: i.nombre,
          cantidad: i.cantidad,
          precio: i.precio,
          total: i.precio * i.cantidad,
          fecha: new Date().toISOString(),
        }));

        if (destino === "habitacion") {
          const folio = get().folios.find((f) => f.id === folioId);
          if (!folio) return "Selecciona una habitación ocupada.";
          set((s) => ({
            products: s.products.map((p) => {
              const item = items.find((i) => i.id === p.id);
              if (!item || item.tipo !== "producto") return p;
              return { ...p, stock: p.stock - item.cantidad };
            }),
            folios: s.folios.map((f) =>
              f.id === folio.id
                ? {
                    ...f,
                    cargos: [...f.cargos, ...charges],
                    total: f.total + total,
                  }
                : f,
            ),
          }));
          return `Cargado a Hab ${folio.habNumero}: ${money(total)}`;
        }

        set((s) => ({
          products: s.products.map((p) => {
            const item = items.find((i) => i.id === p.id);
            if (!item || item.tipo !== "producto") return p;
            return { ...p, stock: p.stock - item.cantidad };
          }),
          sales: [
            ...s.sales,
            {
              id: uid(),
              fecha: new Date().toISOString(),
              tipo: "venta",
              detalle: items.map((i) => `${i.cantidad}× ${i.nombre}`).join(", "),
              items: charges,
              total,
              metodo,
            },
          ],
        }));
        return `Venta registrada: ${money(total)}`;
      },

      exportJson: () => {
        const s = get();
        return JSON.stringify(
          {
            rooms: s.rooms,
            reservations: s.reservations,
            products: s.products,
            sales: s.sales,
            folios: s.folios,
            exportado: new Date().toISOString(),
          },
          null,
          2,
        );
      },

      importJson: (raw) => {
        try {
          const d = JSON.parse(raw) as Partial<{
            rooms: Room[];
            reservations: Reservation[];
            products: Product[];
            sales: Sale[];
            folios: Folio[];
          }>;
          set({
            rooms: d.rooms ?? get().rooms,
            reservations: d.reservations ?? get().reservations,
            products: d.products ?? get().products,
            sales: d.sales ?? get().sales,
            folios: d.folios ?? get().folios,
          });
          return null;
        } catch {
          return "No se pudo leer el archivo.";
        }
      },
}));

export function occupancy(rooms: Room[]) {
  return {
    disponible: rooms.filter((r) => r.estado === "disponible").length,
    ocupada: rooms.filter((r) => r.estado === "ocupada").length,
    limpieza: rooms.filter((r) => r.estado === "limpieza").length,
    mantenimiento: rooms.filter((r) => r.estado === "mantenimiento").length,
  };
}

export function salesToday(sales: Sale[]) {
  const hoy = todayISO();
  return sales.filter((v) => v.fecha.slice(0, 10) === hoy).reduce((s, v) => s + v.total, 0);
}
