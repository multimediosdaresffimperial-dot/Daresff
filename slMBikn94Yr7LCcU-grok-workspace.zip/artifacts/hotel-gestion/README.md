# Sistema de Gestión Hotelera

Aplicación web para administrar un hotel completo, incluyendo:

- Habitaciones y su estado
- Reservas
- Check-in / Check-out
- Cuentas de habitación (folio)
- Tienda (snacks y productos de aseo)
- Servicio de lavandería
- Ventas (cobro en caja o carga a habitación)

## Cómo usarla

1. Descarga el archivo `index.html`
2. Ábrelo con doble clic en Chrome, Edge o Firefox
3. Los datos se guardan automáticamente en el navegador

**Importante:** Usa siempre el mismo navegador y haz copias de seguridad con el botón **Exportar**.

## Módulos

| Módulo | Descripción |
|--------|-------------|
| **Dashboard** | Resumen de ocupación, check-ins/outs del día y ventas |
| **Habitaciones** | Alta, edición y control de estado (disponible, ocupada, limpieza, mantenimiento) |
| **Reservas** | Crear y cancelar reservas |
| **Check-in / Out** | Ingreso de huéspedes y cobro final al salir |
| **Tienda** | Inventario de snacks, aseo y servicios de lavandería |
| **Vender** | Punto de venta: cobrar en caja o cargar a la cuenta de una habitación |
| **Cuentas** | Ver los cargos abiertos de cada habitación ocupada |
| **Historial** | Todas las ventas y check-outs realizados |

## Flujo recomendado

1. Crea las habitaciones reales del hotel
2. Carga los productos (snacks, aseo) y servicios de lavandería
3. Registra las reservas
4. Haz el **Check-in** cuando llegue el huésped
5. Durante la estadía, vende productos o servicios y cárgalos a la habitación
6. Al salir, haz el **Check-out** (cobra todo y la habitación pasa a "Limpieza")
7. Cuando terminen de limpiar, marca la habitación como **Disponible**

## Datos de ejemplo

La primera vez verás 6 habitaciones y varios productos/servicios de ejemplo. Puedes editarlos o eliminarlos.
