# Perfumería Tyt – Sistema de Gestión

Aplicación web sencilla para manejar **inventario** y **ventas** de la Perfumería Tyt.

## Cómo usarla

1. Abre el archivo `index.html` con cualquier navegador (Chrome, Edge, Firefox, Safari).
2. No necesitas internet después de la primera carga (solo para los estilos e iconos).
3. Los datos se guardan automáticamente en el navegador (localStorage).

### Recomendación
- Usa siempre el **mismo navegador y la misma computadora/celular** para no perder los datos.
- Haz **copias de seguridad** con el botón **Exportar** (arriba a la derecha).

## Funciones principales

### Dashboard
- Ventas de hoy y del mes
- Cantidad de productos
- Alertas de stock bajo
- Últimas ventas

### Inventario
- Agregar / editar / eliminar productos
- Nombre, marca, categoría, stock, precio de venta, costo y stock mínimo
- Buscar y filtrar por categoría o solo stock bajo
- Alertas visuales cuando el stock está bajo

### Ventas
- Buscar productos y agregarlos al carrito
- Ajustar cantidades
- Aplicar descuentos
- Elegir método de pago (Efectivo, Tarjeta, Transferencia, Mixto)
- Notas opcionales
- Al confirmar la venta se descuenta automáticamente el stock

### Historial
- Todas las ventas registradas
- Filtrar por rango de fechas
- Ver detalle de cada venta

### Exportar / Importar
- **Exportar**: descarga un archivo `.json` con todo el inventario y las ventas (hazlo regularmente).
- **Importar**: carga un backup anterior (útil si cambias de computadora o borramos datos).

## Notas importantes

- Esta versión es **local** (funciona offline y sin servidor).
- Ideal para un solo punto de venta o uso personal.
- Si necesitas:
  - Varios usuarios al mismo tiempo
  - Acceso desde cualquier lugar (nube)
  - Reportes más avanzados / facturación
  - Integración con WhatsApp o impresión de tickets

  avísame y te preparo una versión más completa (con base de datos y hosting).

## Datos de ejemplo

La primera vez que abras la aplicación verás 5 productos de ejemplo. Puedes editarlos o eliminarlos y cargar los tuyos reales.
