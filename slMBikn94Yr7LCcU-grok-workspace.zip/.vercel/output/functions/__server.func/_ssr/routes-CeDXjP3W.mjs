import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { a as Store, c as Receipt, d as KeyRound, f as History, h as BedDouble, i as Trash2, l as Plus, m as CalendarCheck, n as Upload, o as ShoppingBasket, p as Download, s as Search, t as X, u as LayoutGrid } from "../_libs/lucide-react.mjs";
import { a as DialogPortal, i as DialogOverlay, n as DialogClose, o as DialogTitle, r as DialogContent$1, s as Slot, t as Dialog$1 } from "../_libs/@radix-ui/react-dialog+[...].mjs";
import { n as toast, t as Toaster } from "../_libs/sonner.mjs";
import { n as clsx, t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
import { t as create } from "../_libs/zustand.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-CeDXjP3W.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
function uid() {
	return crypto.randomUUID();
}
function todayISO() {
	const d = /* @__PURE__ */ new Date();
	return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}
function addDaysISO(iso, days) {
	const d = /* @__PURE__ */ new Date(iso + "T12:00:00");
	d.setDate(d.getDate() + days);
	return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}
function money(n) {
	return n.toLocaleString("es-MX", {
		style: "currency",
		currency: "MXN",
		minimumFractionDigits: 2
	});
}
function formatDate(iso) {
	if (!iso) return "—";
	const [y, m, d] = iso.slice(0, 10).split("-");
	if (!y || !m || !d) return iso;
	return `${d}/${m}/${y}`;
}
function formatDateTime(iso) {
	const d = new Date(iso);
	if (Number.isNaN(d.getTime())) return iso;
	return d.toLocaleString("es-MX", {
		day: "2-digit",
		month: "2-digit",
		year: "numeric",
		hour: "2-digit",
		minute: "2-digit"
	});
}
function nightsBetween(entrada, salida) {
	const a = /* @__PURE__ */ new Date(entrada + "T00:00:00");
	const b = /* @__PURE__ */ new Date(salida + "T00:00:00");
	const n = Math.round((b.getTime() - a.getTime()) / 864e5);
	return Math.max(1, n);
}
var badgeVariants = cva("inline-flex items-center rounded-full px-2.5 py-0.5 text-[11px] font-medium tracking-wide", {
	variants: { variant: {
		default: "bg-muted text-foreground",
		available: "bg-ok-soft text-ok",
		occupied: "bg-danger-soft text-danger",
		cleaning: "bg-warn-soft text-warn",
		maintenance: "bg-muted text-muted-foreground",
		info: "bg-secondary text-secondary-foreground"
	} },
	defaultVariants: { variant: "default" }
});
function Badge({ className, variant, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: cn(badgeVariants({
			variant,
			className
		})),
		...props
	});
}
var buttonVariants = cva("inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md text-sm font-medium transition-[opacity,transform,background-color,color] duration-150 ease-[var(--ease-out)] disabled:pointer-events-none disabled:opacity-40 [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0 active:scale-[0.98]", {
	variants: {
		variant: {
			default: "bg-primary text-primary-foreground hover:opacity-90",
			secondary: "bg-secondary text-secondary-foreground hover:bg-muted",
			outline: "border border-border bg-card text-foreground hover:bg-muted",
			ghost: "text-foreground hover:bg-muted",
			destructive: "bg-danger text-danger-foreground hover:opacity-90"
		},
		size: {
			default: "h-11 px-4",
			sm: "h-9 px-3 text-xs",
			lg: "h-12 px-5",
			icon: "size-11"
		}
	},
	defaultVariants: {
		variant: "default",
		size: "default"
	}
});
function Button({ className, variant, size, asChild = false, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(asChild ? Slot : "button", {
		className: cn(buttonVariants({
			variant,
			size,
			className
		})),
		...props
	});
}
function Card({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("rounded-xl border border-border bg-card text-card-foreground shadow-sm", className),
		...props
	});
}
function CardContent({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("p-5", className),
		...props
	});
}
var Dialog = Dialog$1;
function DialogContent({ className, children, title, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogPortal, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogOverlay, { className: "fixed inset-0 z-50 bg-ink/40" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent$1, {
		className: cn("fixed top-1/2 left-1/2 z-50 w-[min(28rem,calc(100vw-1.5rem))] -translate-x-1/2 -translate-y-1/2 rounded-2xl border border-border bg-card p-5 text-card-foreground shadow-lg outline-none", className),
		...props,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mb-4 flex items-start justify-between gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, {
				className: "font-display text-lg font-medium tracking-tight",
				children: title
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogClose, {
				className: "inline-flex size-9 items-center justify-center rounded-md text-muted-foreground hover:bg-muted",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "sr-only",
					children: "Cerrar"
				})]
			})]
		}), children]
	})] });
}
function Input({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
		className: cn("flex h-11 w-full rounded-md border border-border bg-card px-3 text-sm text-foreground outline-none transition-[box-shadow,border-color] duration-150 placeholder:text-muted-foreground focus-visible:ring-2 focus-visible:ring-ring", className),
		...props
	});
}
function Label({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
		className: cn("text-xs font-medium tracking-wide text-muted-foreground", className),
		...props
	});
}
function NativeSelect({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
		className: cn("flex h-11 w-full rounded-md border border-border bg-card px-3 text-sm text-foreground outline-none focus-visible:ring-2 focus-visible:ring-ring", className),
		...props
	});
}
function Textarea({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
		className: cn("flex min-h-20 w-full rounded-md border border-border bg-card px-3 py-2 text-sm text-foreground outline-none transition-[box-shadow,border-color] duration-150 placeholder:text-muted-foreground focus-visible:ring-2 focus-visible:ring-ring", className),
		...props
	});
}
function seedRooms() {
	const mk = (id, numero, tipo, precio, estado) => ({
		id,
		numero,
		tipo,
		precio,
		estado
	});
	return [
		mk("r101", "101", "Individual", 450, "disponible"),
		mk("r102", "102", "Doble", 650, "disponible"),
		mk("r103", "103", "Matrimonial", 700, "disponible"),
		mk("r201", "201", "Suite", 1200, "disponible"),
		mk("r202", "202", "Familiar", 950, "disponible"),
		mk("r203", "203", "Doble", 650, "limpieza")
	];
}
function seedProducts() {
	const mk = (id, nombre, categoria, tipo, stock, precio) => ({
		id,
		nombre,
		categoria,
		tipo,
		stock,
		precio
	});
	return [
		mk("p1", "Agua mineral 500ml", "Snack", "producto", 48, 25),
		mk("p2", "Refresco 355ml", "Snack", "producto", 36, 30),
		mk("p3", "Papas fritas", "Snack", "producto", 24, 35),
		mk("p4", "Chocolate", "Snack", "producto", 20, 28),
		mk("p5", "Jabón de tocador", "Aseo", "producto", 40, 15),
		mk("p6", "Shampoo sobrecito", "Aseo", "producto", 50, 12),
		mk("p7", "Pasta dental", "Aseo", "producto", 30, 20),
		mk("p8", "Lavado de camisa", "Lavandería", "servicio", 0, 45),
		mk("p9", "Lavado de pantalón", "Lavandería", "servicio", 0, 55),
		mk("p10", "Lavado de vestido", "Lavandería", "servicio", 0, 80),
		mk("p11", "Planchado", "Lavandería", "servicio", 0, 30)
	];
}
var STORAGE_KEY = "posada-tyt-v1";
function loadHotelFromStorage() {
	if (typeof window === "undefined") return;
	try {
		const raw = localStorage.getItem(STORAGE_KEY);
		if (!raw) return;
		const d = JSON.parse(raw);
		useHotel.setState({
			rooms: d.rooms ?? useHotel.getState().rooms,
			reservations: d.reservations ?? [],
			products: d.products ?? useHotel.getState().products,
			sales: d.sales ?? [],
			folios: d.folios ?? []
		});
	} catch {}
}
function persistHotel() {
	if (typeof window === "undefined") return;
	const s = useHotel.getState();
	localStorage.setItem(STORAGE_KEY, JSON.stringify({
		rooms: s.rooms,
		reservations: s.reservations,
		products: s.products,
		sales: s.sales,
		folios: s.folios
	}));
}
var useHotel = create()((set, get) => ({
	rooms: seedRooms(),
	reservations: [],
	products: seedProducts(),
	sales: [],
	folios: [],
	hydrated: false,
	setHydrated: (v) => set({ hydrated: v }),
	upsertRoom: (room) => {
		set((s) => {
			if (room.id) return { rooms: s.rooms.map((r) => r.id === room.id ? {
				...r,
				...room,
				id: r.id
			} : r) };
			return { rooms: [...s.rooms, {
				...room,
				id: uid()
			}] };
		});
	},
	deleteRoom: (id) => {
		if (get().folios.some((f) => f.habId === id)) return "No se puede eliminar: hay una cuenta abierta.";
		set((s) => ({ rooms: s.rooms.filter((r) => r.id !== id) }));
		return null;
	},
	setRoomStatus: (id, estado) => {
		set((s) => ({ rooms: s.rooms.map((r) => r.id === id ? {
			...r,
			estado
		} : r) }));
	},
	addReservation: (data) => {
		const hab = get().rooms.find((r) => r.id === data.habId);
		if (!hab) return "Selecciona una habitación.";
		if (data.salida <= data.entrada) return "La salida debe ser posterior a la entrada.";
		set((s) => ({ reservations: [...s.reservations, {
			id: uid(),
			nombre: data.nombre.trim(),
			tel: data.tel.trim(),
			doc: data.doc.trim(),
			habId: hab.id,
			habNumero: hab.numero,
			entrada: data.entrada,
			salida: data.salida,
			notas: data.notas.trim(),
			estado: "confirmada",
			precioNoche: hab.precio
		}] }));
		return null;
	},
	cancelReservation: (id) => {
		set((s) => ({ reservations: s.reservations.map((r) => r.id === id && r.estado === "confirmada" ? {
			...r,
			estado: "cancelada"
		} : r) }));
	},
	checkIn: (reservationId) => {
		const r = get().reservations.find((x) => x.id === reservationId);
		if (!r || r.estado !== "confirmada") return "Reserva no válida.";
		const hab = get().rooms.find((h) => h.id === r.habId);
		if (!hab) return "Habitación no encontrada.";
		if (hab.estado !== "disponible") return "La habitación no está disponible.";
		const noches = nightsBetween(r.entrada, r.salida);
		const cargo = {
			id: uid(),
			concepto: `Alojamiento ${noches} noche(s)`,
			cantidad: noches,
			precio: r.precioNoche,
			total: noches * r.precioNoche,
			fecha: (/* @__PURE__ */ new Date()).toISOString()
		};
		set((s) => ({
			rooms: s.rooms.map((h) => h.id === hab.id ? {
				...h,
				estado: "ocupada"
			} : h),
			reservations: s.reservations.map((x) => x.id === r.id ? {
				...x,
				estado: "checkin"
			} : x),
			folios: [...s.folios, {
				id: uid(),
				reservaId: r.id,
				habId: r.habId,
				habNumero: r.habNumero,
				huesped: r.nombre,
				entrada: r.entrada,
				salidaPrevista: r.salida,
				checkIn: (/* @__PURE__ */ new Date()).toISOString(),
				precioNoche: r.precioNoche,
				noches,
				cargos: [cargo],
				total: cargo.total
			}]
		}));
		return null;
	},
	checkOut: (folioId) => {
		const folio = get().folios.find((f) => f.id === folioId);
		if (!folio) return "Cuenta no encontrada.";
		const sale = {
			id: uid(),
			fecha: (/* @__PURE__ */ new Date()).toISOString(),
			tipo: "checkout",
			detalle: `Check-out Hab ${folio.habNumero} · ${folio.huesped}`,
			items: folio.cargos,
			total: folio.total,
			metodo: "Check-out"
		};
		set((s) => ({
			sales: [...s.sales, sale],
			rooms: s.rooms.map((h) => h.id === folio.habId ? {
				...h,
				estado: "limpieza"
			} : h),
			reservations: s.reservations.map((r) => r.id === folio.reservaId ? {
				...r,
				estado: "completada"
			} : r),
			folios: s.folios.filter((f) => f.id !== folioId)
		}));
		return null;
	},
	upsertProduct: (p) => {
		set((s) => {
			if (p.id) return { products: s.products.map((x) => x.id === p.id ? {
				...x,
				...p,
				id: x.id
			} : x) };
			return { products: [...s.products, {
				...p,
				id: uid()
			}] };
		});
	},
	deleteProduct: (id) => {
		set((s) => ({ products: s.products.filter((p) => p.id !== id) }));
	},
	sell: ({ items, descuento, destino, folioId, metodo }) => {
		if (!items.length) return "Agrega productos o servicios.";
		const products = get().products;
		for (const item of items) if (item.tipo === "producto") {
			const p = products.find((x) => x.id === item.id);
			if (!p || p.stock < item.cantidad) return `Sin stock de ${item.nombre}.`;
		}
		const sub = items.reduce((s, i) => s + i.precio * i.cantidad, 0);
		const total = Math.max(0, sub - (descuento || 0));
		const charges = items.map((i) => ({
			id: uid(),
			concepto: i.nombre,
			cantidad: i.cantidad,
			precio: i.precio,
			total: i.precio * i.cantidad,
			fecha: (/* @__PURE__ */ new Date()).toISOString()
		}));
		if (destino === "habitacion") {
			const folio = get().folios.find((f) => f.id === folioId);
			if (!folio) return "Selecciona una habitación ocupada.";
			set((s) => ({
				products: s.products.map((p) => {
					const item = items.find((i) => i.id === p.id);
					if (!item || item.tipo !== "producto") return p;
					return {
						...p,
						stock: p.stock - item.cantidad
					};
				}),
				folios: s.folios.map((f) => f.id === folio.id ? {
					...f,
					cargos: [...f.cargos, ...charges],
					total: f.total + total
				} : f)
			}));
			return `Cargado a Hab ${folio.habNumero}: ${money(total)}`;
		}
		set((s) => ({
			products: s.products.map((p) => {
				const item = items.find((i) => i.id === p.id);
				if (!item || item.tipo !== "producto") return p;
				return {
					...p,
					stock: p.stock - item.cantidad
				};
			}),
			sales: [...s.sales, {
				id: uid(),
				fecha: (/* @__PURE__ */ new Date()).toISOString(),
				tipo: "venta",
				detalle: items.map((i) => `${i.cantidad}× ${i.nombre}`).join(", "),
				items: charges,
				total,
				metodo
			}]
		}));
		return `Venta registrada: ${money(total)}`;
	},
	exportJson: () => {
		const s = get();
		return JSON.stringify({
			rooms: s.rooms,
			reservations: s.reservations,
			products: s.products,
			sales: s.sales,
			folios: s.folios,
			exportado: (/* @__PURE__ */ new Date()).toISOString()
		}, null, 2);
	},
	importJson: (raw) => {
		try {
			const d = JSON.parse(raw);
			set({
				rooms: d.rooms ?? get().rooms,
				reservations: d.reservations ?? get().reservations,
				products: d.products ?? get().products,
				sales: d.sales ?? get().sales,
				folios: d.folios ?? get().folios
			});
			return null;
		} catch {
			return "No se pudo leer el archivo.";
		}
	}
}));
function occupancy(rooms) {
	return {
		disponible: rooms.filter((r) => r.estado === "disponible").length,
		ocupada: rooms.filter((r) => r.estado === "ocupada").length,
		limpieza: rooms.filter((r) => r.estado === "limpieza").length,
		mantenimiento: rooms.filter((r) => r.estado === "mantenimiento").length
	};
}
function salesToday(sales) {
	const hoy = todayISO();
	return sales.filter((v) => v.fecha.slice(0, 10) === hoy).reduce((s, v) => s + v.total, 0);
}
var TABS = [
	{
		id: "tablero",
		label: "Tablero",
		icon: LayoutGrid
	},
	{
		id: "habitaciones",
		label: "Habitaciones",
		icon: BedDouble
	},
	{
		id: "reservas",
		label: "Reservas",
		icon: CalendarCheck
	},
	{
		id: "recepcion",
		label: "Recepción",
		icon: KeyRound
	},
	{
		id: "tienda",
		label: "Tienda",
		icon: Store
	},
	{
		id: "vender",
		label: "Vender",
		icon: ShoppingBasket
	},
	{
		id: "cuentas",
		label: "Cuentas",
		icon: Receipt
	},
	{
		id: "historial",
		label: "Historial",
		icon: History
	}
];
var STATUS_BADGE = {
	disponible: "available",
	ocupada: "occupied",
	limpieza: "cleaning",
	mantenimiento: "maintenance"
};
function HotelApp() {
	const [tab, setTab] = (0, import_react.useState)("tablero");
	(0, import_react.useEffect)(() => {
		loadHotelFromStorage();
		return useHotel.subscribe(() => persistHotel());
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-dvh bg-bg text-fg",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toaster, {
				position: "bottom-right",
				richColors: false
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "sticky top-0 z-20 border-b border-border bg-card/95 backdrop-blur",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto flex max-w-6xl flex-wrap items-center justify-between gap-3 px-4 py-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex size-10 items-center justify-center rounded-lg bg-primary text-primary-foreground",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BedDouble, { className: "size-5" })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-display text-lg leading-tight font-medium tracking-tight",
							children: "Posada Tyt"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-muted-foreground",
							children: "Recepción · habitaciones · tienda"
						})] })]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BackupButtons, {})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
					className: "mx-auto max-w-6xl overflow-x-auto px-2 pb-2",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex min-w-max gap-1",
						children: TABS.map((t) => {
							const Icon = t.icon;
							const active = tab === t.id;
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								onClick: () => setTab(t.id),
								className: cn("inline-flex h-11 items-center gap-2 rounded-lg px-3 text-sm font-medium whitespace-nowrap transition-colors duration-150", active ? "bg-primary text-primary-foreground" : "text-muted-foreground hover:bg-muted hover:text-fg"),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-4" }), t.label]
							}, t.id);
						})
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
				className: "mx-auto max-w-6xl px-4 py-6",
				children: [
					tab === "tablero" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dashboard, { onGo: setTab }),
					tab === "habitaciones" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RoomsView, {}),
					tab === "reservas" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ReservationsView, {}),
					tab === "recepcion" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FrontDeskView, {}),
					tab === "tienda" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShopView, {}),
					tab === "vender" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PosView, {}),
					tab === "cuentas" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FoliosView, {}),
					tab === "historial" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HistoryView, {})
				]
			})
		]
	});
}
function BackupButtons() {
	const exportJson = useHotel((s) => s.exportJson);
	const importJson = useHotel((s) => s.importJson);
	function onExport() {
		const blob = new Blob([exportJson()], { type: "application/json" });
		const a = document.createElement("a");
		a.href = URL.createObjectURL(blob);
		a.download = `posada-tyt-${todayISO()}.json`;
		a.click();
		toast.success("Copia descargada");
	}
	function onImport() {
		const input = document.createElement("input");
		input.type = "file";
		input.accept = "application/json";
		input.onchange = () => {
			const file = input.files?.[0];
			if (!file) return;
			const reader = new FileReader();
			reader.onload = () => {
				const err = importJson(String(reader.result ?? ""));
				if (err) toast.error(err);
				else toast.success("Datos restaurados");
			};
			reader.readAsText(file);
		};
		input.click();
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex gap-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
			variant: "outline",
			size: "sm",
			onClick: onExport,
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, {}), " Exportar"]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
			variant: "outline",
			size: "sm",
			onClick: onImport,
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Upload, {}), " Importar"]
		})]
	});
}
function Dashboard({ onGo }) {
	const rooms = useHotel((s) => s.rooms);
	const reservations = useHotel((s) => s.reservations);
	const folios = useHotel((s) => s.folios);
	const sales = useHotel((s) => s.sales);
	const occ = occupancy(rooms);
	const hoy = todayISO();
	const ci = reservations.filter((r) => r.estado === "confirmada" && r.entrada === hoy).length;
	const co = folios.filter((f) => f.salidaPrevista === hoy).length;
	const movements = [...reservations.filter((r) => r.estado === "confirmada" && (r.entrada === hoy || r.salida === hoy)).map((r) => ({
		id: r.id,
		tipo: r.entrada === hoy ? "Check-in" : "Salida prevista",
		nombre: r.nombre,
		hab: r.habNumero
	})), ...folios.filter((f) => f.salidaPrevista === hoy).map((f) => ({
		id: f.id,
		tipo: "Check-out hoy",
		nombre: f.huesped,
		hab: f.habNumero
	}))];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-display text-3xl tracking-tight",
				children: "Tablero"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-sm text-muted-foreground",
				children: "Ocupación y movimiento del día."
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 gap-3 md:grid-cols-3 lg:grid-cols-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kpi, {
						label: "Disponibles",
						value: occ.disponible
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kpi, {
						label: "Ocupadas",
						value: occ.ocupada
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kpi, {
						label: "Limpieza",
						value: occ.limpieza
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kpi, {
						label: "Check-in hoy",
						value: ci
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kpi, {
						label: "Check-out hoy",
						value: co
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kpi, {
						label: "Ventas hoy",
						value: money(salesToday(sales)),
						wide: true
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-4 lg:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-3 flex items-center justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-base",
						children: "Habitaciones"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "ghost",
						size: "sm",
						onClick: () => onGo("habitaciones"),
						children: "Ver todas"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid grid-cols-3 gap-2 sm:grid-cols-4",
					children: [...rooms].sort((a, b) => a.numero.localeCompare(b.numero, void 0, { numeric: true })).map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: cn("rounded-lg border border-border p-3", r.estado === "disponible" && "border-l-4 border-l-ok", r.estado === "ocupada" && "border-l-4 border-l-danger", r.estado === "limpieza" && "border-l-4 border-l-warn"),
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-display text-lg leading-none",
								children: r.numero
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-xs text-muted-foreground",
								children: r.tipo
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-[11px] tracking-wide uppercase",
								children: r.estado
							})
						]
					}, r.id))
				})] }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display mb-3 text-base",
					children: "Hoy"
				}), movements.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted-foreground",
					children: "Sin llegadas ni salidas programadas."
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "space-y-2",
					children: movements.map((m) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex items-center justify-between rounded-lg bg-muted px-3 py-2 text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-medium",
							children: m.tipo
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "text-muted-foreground",
							children: [" · ", m.nombre]
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "tabular text-muted-foreground",
							children: ["Hab ", m.hab]
						})]
					}, m.id + m.tipo))
				})] }) })]
			})
		]
	});
}
function Kpi({ label, value, wide }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, {
		className: cn("py-4", wide && "col-span-2 sm:col-span-1"),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-xs text-muted-foreground",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "font-display mt-1 text-2xl tabular tracking-tight",
			children: value
		})]
	}) });
}
function RoomsView() {
	const rooms = useHotel((s) => s.rooms);
	const folios = useHotel((s) => s.folios);
	const upsertRoom = useHotel((s) => s.upsertRoom);
	const deleteRoom = useHotel((s) => s.deleteRoom);
	const setRoomStatus = useHotel((s) => s.setRoomStatus);
	const [open, setOpen] = (0, import_react.useState)(false);
	const [editing, setEditing] = (0, import_react.useState)(null);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-end justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "font-display text-3xl tracking-tight",
					children: "Habitaciones"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm text-muted-foreground",
					children: "Estados, tipos y tarifa por noche."
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					onClick: () => {
						setEditing(null);
						setOpen(true);
					},
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, {}), " Nueva"]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "overflow-x-auto",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
					className: "w-full min-w-[640px] text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
						className: "border-b border-border bg-muted/60 text-left text-xs text-muted-foreground",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-4 py-3 font-medium",
								children: "Nº"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-4 py-3 font-medium",
								children: "Tipo"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-4 py-3 font-medium",
								children: "Estado"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-4 py-3 text-right font-medium",
								children: "Precio"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-4 py-3 font-medium",
								children: "Huésped"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-4 py-3 text-right font-medium",
								children: " "
							})
						] })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: [...rooms].sort((a, b) => a.numero.localeCompare(b.numero, void 0, { numeric: true })).map((r) => {
						const folio = folios.find((f) => f.habId === r.id);
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
							className: "border-b border-border last:border-0",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-4 py-3 font-medium",
									children: r.numero
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-4 py-3",
									children: r.tipo
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-4 py-3",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
										variant: STATUS_BADGE[r.estado],
										children: r.estado
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-4 py-3 text-right tabular",
									children: money(r.precio)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-4 py-3",
									children: folio?.huesped ?? "—"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-4 py-3 text-right",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "inline-flex gap-1",
										children: [
											r.estado === "limpieza" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
												size: "sm",
												variant: "ghost",
												onClick: () => setRoomStatus(r.id, "disponible"),
												children: "Disponible"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
												size: "sm",
												variant: "ghost",
												onClick: () => {
													setEditing(r);
													setOpen(true);
												},
												children: "Editar"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
												size: "icon",
												variant: "ghost",
												onClick: () => {
													const err = deleteRoom(r.id);
													if (err) toast.error(err);
												},
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, {})
											})
										]
									})
								})
							]
						}, r.id);
					}) })]
				})
			}) }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RoomDialog, {
				open,
				onOpenChange: setOpen,
				room: editing,
				onSave: upsertRoom
			})
		]
	});
}
function RoomDialog({ open, onOpenChange, room, onSave }) {
	const [numero, setNumero] = (0, import_react.useState)("");
	const [tipo, setTipo] = (0, import_react.useState)("Individual");
	const [precio, setPrecio] = (0, import_react.useState)("0");
	const [estado, setEstado] = (0, import_react.useState)("disponible");
	(0, import_react.useEffect)(() => {
		if (open) {
			setNumero(room?.numero ?? "");
			setTipo(room?.tipo ?? "Individual");
			setPrecio(String(room?.precio ?? 0));
			setEstado(room?.estado ?? "disponible");
		}
	}, [open, room]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open,
		onOpenChange,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogContent, {
			title: room ? "Editar habitación" : "Nueva habitación",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: "space-y-3",
				onSubmit: (e) => {
					e.preventDefault();
					onSave({
						id: room?.id,
						numero: numero.trim(),
						tipo,
						precio: Number(precio) || 0,
						estado
					});
					onOpenChange(false);
					toast.success("Habitación guardada");
				},
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Número",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							required: true,
							value: numero,
							onChange: (e) => setNumero(e.target.value)
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-2 gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Tipo",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NativeSelect, {
								value: tipo,
								onChange: (e) => setTipo(e.target.value),
								children: [
									"Individual",
									"Doble",
									"Matrimonial",
									"Suite",
									"Familiar"
								].map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: t }, t))
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Precio / noche",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								type: "number",
								min: "0",
								step: "0.01",
								value: precio,
								onChange: (e) => setPrecio(e.target.value)
							})
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Estado",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NativeSelect, {
							value: estado,
							onChange: (e) => setEstado(e.target.value),
							children: [
								"disponible",
								"ocupada",
								"limpieza",
								"mantenimiento"
							].map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: t,
								children: t
							}, t))
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex justify-end gap-2 pt-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "button",
							variant: "outline",
							onClick: () => onOpenChange(false),
							children: "Cancelar"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "submit",
							children: "Guardar"
						})]
					})
				]
			})
		})
	});
}
function Field({ label, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-1.5",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: label }), children]
	});
}
function ReservationsView() {
	const reservations = useHotel((s) => s.reservations);
	const rooms = useHotel((s) => s.rooms);
	const addReservation = useHotel((s) => s.addReservation);
	const cancelReservation = useHotel((s) => s.cancelReservation);
	const [open, setOpen] = (0, import_react.useState)(false);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-end justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "font-display text-3xl tracking-tight",
					children: "Reservas"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm text-muted-foreground",
					children: "Llegadas confirmadas y cancelaciones."
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					onClick: () => setOpen(true),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, {}), " Nueva reserva"]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "overflow-x-auto",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
					className: "w-full min-w-[720px] text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
						className: "border-b border-border bg-muted/60 text-left text-xs text-muted-foreground",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-4 py-3 font-medium",
								children: "Huésped"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-4 py-3 font-medium",
								children: "Habitación"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-4 py-3 font-medium",
								children: "Entrada"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-4 py-3 font-medium",
								children: "Salida"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-4 py-3 font-medium",
								children: "Estado"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { className: "px-4 py-3" })
						] })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: reservations.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
						colSpan: 6,
						className: "px-4 py-10 text-center text-muted-foreground",
						children: "Aún no hay reservas."
					}) }) : [...reservations].sort((a, b) => a.entrada.localeCompare(b.entrada)).map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
						className: "border-b border-border last:border-0",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
								className: "px-4 py-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "font-medium",
									children: r.nombre
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "text-xs text-muted-foreground",
									children: [r.tel, r.doc ? ` · ${r.doc}` : ""]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
								className: "px-4 py-3",
								children: ["Hab ", r.habNumero]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-4 py-3",
								children: formatDate(r.entrada)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-4 py-3",
								children: formatDate(r.salida)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-4 py-3",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
									variant: r.estado === "confirmada" ? "info" : r.estado === "checkin" ? "available" : "default",
									children: r.estado
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-4 py-3 text-right",
								children: r.estado === "confirmada" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									size: "sm",
									variant: "ghost",
									onClick: () => cancelReservation(r.id),
									children: "Cancelar"
								})
							})
						]
					}, r.id)) })]
				})
			}) }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ReservationDialog, {
				open,
				onOpenChange: setOpen,
				rooms,
				onSave: addReservation
			})
		]
	});
}
function ReservationDialog({ open, onOpenChange, rooms, onSave }) {
	const [nombre, setNombre] = (0, import_react.useState)("");
	const [tel, setTel] = (0, import_react.useState)("");
	const [doc, setDoc] = (0, import_react.useState)("");
	const [habId, setHabId] = (0, import_react.useState)("");
	const [entrada, setEntrada] = (0, import_react.useState)(todayISO());
	const [salida, setSalida] = (0, import_react.useState)(addDaysISO(todayISO(), 1));
	const [notas, setNotas] = (0, import_react.useState)("");
	(0, import_react.useEffect)(() => {
		if (open) {
			setNombre("");
			setTel("");
			setDoc("");
			setHabId(rooms[0]?.id ?? "");
			setEntrada(todayISO());
			setSalida(addDaysISO(todayISO(), 1));
			setNotas("");
		}
	}, [open, rooms]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open,
		onOpenChange,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogContent, {
			title: "Nueva reserva",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: "space-y-3",
				onSubmit: (e) => {
					e.preventDefault();
					const err = onSave({
						nombre,
						tel,
						doc,
						habId,
						entrada,
						salida,
						notas
					});
					if (err) {
						toast.error(err);
						return;
					}
					onOpenChange(false);
					toast.success("Reserva creada");
				},
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Huésped",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							required: true,
							value: nombre,
							onChange: (e) => setNombre(e.target.value)
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-2 gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Teléfono",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								value: tel,
								onChange: (e) => setTel(e.target.value)
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Documento",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								value: doc,
								onChange: (e) => setDoc(e.target.value)
							})
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Habitación",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NativeSelect, {
							value: habId,
							onChange: (e) => setHabId(e.target.value),
							required: true,
							children: rooms.map((h) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
								value: h.id,
								children: [
									h.numero,
									" · ",
									h.tipo,
									" · ",
									money(h.precio)
								]
							}, h.id))
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-2 gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Entrada",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								id: "res-entrada",
								type: "date",
								required: true,
								value: entrada,
								onChange: (e) => setEntrada(e.target.value)
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Salida",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								id: "res-salida",
								type: "date",
								required: true,
								value: salida,
								onChange: (e) => setSalida(e.target.value)
							})
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Notas",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
							value: notas,
							onChange: (e) => setNotas(e.target.value),
							rows: 2
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex justify-end gap-2 pt-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "button",
							variant: "outline",
							onClick: () => onOpenChange(false),
							children: "Cancelar"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "submit",
							children: "Guardar"
						})]
					})
				]
			})
		})
	});
}
function FrontDeskView() {
	const reservations = useHotel((s) => s.reservations);
	const rooms = useHotel((s) => s.rooms);
	const folios = useHotel((s) => s.folios);
	const checkIn = useHotel((s) => s.checkIn);
	const checkOut = useHotel((s) => s.checkOut);
	const [resId, setResId] = (0, import_react.useState)("");
	const [folioId, setFolioId] = (0, import_react.useState)("");
	const confirmadas = reservations.filter((r) => r.estado === "confirmada");
	const reserva = confirmadas.find((r) => r.id === resId);
	const hab = rooms.find((h) => h.id === reserva?.habId);
	const folio = folios.find((f) => f.id === folioId);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "font-display text-3xl tracking-tight",
			children: "Recepción"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-1 text-sm text-muted-foreground",
			children: "Check-in, check-out y cobro de la cuenta."
		})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid gap-4 lg:grid-cols-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, {
				className: "space-y-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-base",
						children: "Check-in"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Reserva confirmada",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(NativeSelect, {
							value: resId,
							onChange: (e) => setResId(e.target.value),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "",
								children: "Elegir reserva"
							}), confirmadas.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
								value: r.id,
								children: [
									r.nombre,
									" · Hab ",
									r.habNumero,
									" · ",
									formatDate(r.entrada)
								]
							}, r.id))]
						})
					}),
					reserva && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-lg bg-ok-soft p-3 text-sm text-ok",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-medium",
								children: reserva.nombre
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
								"Hab ",
								reserva.habNumero,
								hab ? ` · ${hab.tipo}` : ""
							] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
								formatDate(reserva.entrada),
								" → ",
								formatDate(reserva.salida)
							] }),
							hab && hab.estado !== "disponible" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 font-medium text-danger",
								children: "La habitación no está disponible."
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						className: "w-full",
						disabled: !reserva || hab?.estado !== "disponible",
						onClick: () => {
							const err = checkIn(resId);
							if (err) toast.error(err);
							else {
								toast.success(`Check-in: Hab ${reserva?.habNumero}`);
								setResId("");
							}
						},
						children: "Confirmar check-in"
					})
				]
			}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, {
				className: "space-y-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-base",
						children: "Check-out"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Habitación ocupada",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(NativeSelect, {
							value: folioId,
							onChange: (e) => setFolioId(e.target.value),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "",
								children: "Elegir habitación"
							}), folios.map((f) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
								value: f.id,
								children: [
									"Hab ",
									f.habNumero,
									" · ",
									f.huesped
								]
							}, f.id))]
						})
					}),
					folio && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-2 rounded-lg bg-danger-soft p-3 text-sm",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "font-medium",
								children: [
									folio.huesped,
									" · Hab ",
									folio.habNumero
								]
							}),
							folio.cargos.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex justify-between text-xs",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
									c.concepto,
									" ×",
									c.cantidad
								] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "tabular",
									children: money(c.total)
								})]
							}, c.id)),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-display text-right text-lg",
								children: money(folio.total)
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						className: "w-full",
						variant: "destructive",
						disabled: !folio,
						onClick: () => {
							if (!folio) return;
							const err = checkOut(folio.id);
							if (err) toast.error(err);
							else {
								toast.success(`Check-out cobrado: ${money(folio.total)}`);
								setFolioId("");
							}
						},
						children: "Cobrar y hacer check-out"
					})
				]
			}) })]
		})]
	});
}
function ShopView() {
	const products = useHotel((s) => s.products);
	const upsertProduct = useHotel((s) => s.upsertProduct);
	const deleteProduct = useHotel((s) => s.deleteProduct);
	const [cat, setCat] = (0, import_react.useState)("");
	const [open, setOpen] = (0, import_react.useState)(false);
	const [editing, setEditing] = (0, import_react.useState)(null);
	const list = cat ? products.filter((p) => p.categoria === cat) : products;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-end justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "font-display text-3xl tracking-tight",
					children: "Tienda"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm text-muted-foreground",
					children: "Snacks, aseo y lavandería."
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					onClick: () => {
						setEditing(null);
						setOpen(true);
					},
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, {}), " Nuevo ítem"]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex flex-wrap gap-2",
				children: [
					"",
					"Snack",
					"Aseo",
					"Lavandería",
					"Otro"
				].map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => setCat(c),
					className: cn("h-10 rounded-full px-3 text-sm", cat === c ? "bg-primary text-primary-foreground" : "bg-muted text-muted-foreground"),
					children: c || "Todos"
				}, c || "all"))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "overflow-x-auto",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
					className: "w-full min-w-[560px] text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
						className: "border-b border-border bg-muted/60 text-left text-xs text-muted-foreground",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-4 py-3 font-medium",
								children: "Nombre"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-4 py-3 font-medium",
								children: "Categoría"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-4 py-3 text-right font-medium",
								children: "Stock"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-4 py-3 text-right font-medium",
								children: "Precio"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { className: "px-4 py-3" })
						] })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: list.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
						className: "border-b border-border last:border-0",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-4 py-3 font-medium",
								children: p.nombre
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-4 py-3",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, { children: p.categoria })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-4 py-3 text-right tabular",
								children: p.tipo === "servicio" ? "—" : p.stock
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-4 py-3 text-right tabular",
								children: money(p.precio)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
								className: "px-4 py-3 text-right",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									size: "sm",
									variant: "ghost",
									onClick: () => {
										setEditing(p);
										setOpen(true);
									},
									children: "Editar"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									size: "icon",
									variant: "ghost",
									onClick: () => deleteProduct(p.id),
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, {})
								})]
							})
						]
					}, p.id)) })]
				})
			}) }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProductDialog, {
				open,
				onOpenChange: setOpen,
				product: editing,
				onSave: upsertProduct
			})
		]
	});
}
function ProductDialog({ open, onOpenChange, product, onSave }) {
	const [nombre, setNombre] = (0, import_react.useState)("");
	const [categoria, setCategoria] = (0, import_react.useState)("Snack");
	const [tipo, setTipo] = (0, import_react.useState)("producto");
	const [stock, setStock] = (0, import_react.useState)("0");
	const [precio, setPrecio] = (0, import_react.useState)("0");
	(0, import_react.useEffect)(() => {
		if (open) {
			setNombre(product?.nombre ?? "");
			setCategoria(product?.categoria ?? "Snack");
			setTipo(product?.tipo ?? "producto");
			setStock(String(product?.stock ?? 0));
			setPrecio(String(product?.precio ?? 0));
		}
	}, [open, product]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open,
		onOpenChange,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogContent, {
			title: product ? "Editar ítem" : "Nuevo producto o servicio",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: "space-y-3",
				onSubmit: (e) => {
					e.preventDefault();
					onSave({
						id: product?.id,
						nombre: nombre.trim(),
						categoria,
						tipo,
						stock: Number(stock) || 0,
						precio: Number(precio) || 0
					});
					onOpenChange(false);
					toast.success("Guardado");
				},
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Nombre",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							required: true,
							value: nombre,
							onChange: (e) => setNombre(e.target.value)
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-2 gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Categoría",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NativeSelect, {
								value: categoria,
								onChange: (e) => setCategoria(e.target.value),
								children: [
									"Snack",
									"Aseo",
									"Lavandería",
									"Otro"
								].map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: c }, c))
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Tipo",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(NativeSelect, {
								value: tipo,
								onChange: (e) => setTipo(e.target.value),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "producto",
									children: "Producto (stock)"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "servicio",
									children: "Servicio"
								})]
							})
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-2 gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Stock",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								type: "number",
								min: "0",
								value: stock,
								onChange: (e) => setStock(e.target.value)
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Precio",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								type: "number",
								min: "0",
								step: "0.01",
								value: precio,
								onChange: (e) => setPrecio(e.target.value)
							})
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex justify-end gap-2 pt-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "button",
							variant: "outline",
							onClick: () => onOpenChange(false),
							children: "Cancelar"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "submit",
							children: "Guardar"
						})]
					})
				]
			})
		})
	});
}
function PosView() {
	const products = useHotel((s) => s.products);
	const folios = useHotel((s) => s.folios);
	const sell = useHotel((s) => s.sell);
	const [q, setQ] = (0, import_react.useState)("");
	const [cart, setCart] = (0, import_react.useState)([]);
	const [descuento, setDescuento] = (0, import_react.useState)("0");
	const [destino, setDestino] = (0, import_react.useState)("caja");
	const [folioId, setFolioId] = (0, import_react.useState)(folios[0]?.id ?? "");
	const [metodo, setMetodo] = (0, import_react.useState)("Efectivo");
	const results = (0, import_react.useMemo)(() => {
		const n = q.toLowerCase();
		if (!n) return [];
		return products.filter((p) => p.nombre.toLowerCase().includes(n) && (p.tipo === "servicio" || p.stock > 0)).slice(0, 8);
	}, [q, products]);
	const sub = cart.reduce((s, i) => s + i.precio * i.cantidad, 0);
	const total = Math.max(0, sub - (Number(descuento) || 0));
	function add(p) {
		setCart((prev) => {
			const exist = prev.find((i) => i.id === p.id);
			if (exist) {
				if (p.tipo === "producto" && exist.cantidad >= p.stock) {
					toast.error("Sin stock");
					return prev;
				}
				return prev.map((i) => i.id === p.id ? {
					...i,
					cantidad: i.cantidad + 1
				} : i);
			}
			return [...prev, {
				id: p.id,
				nombre: p.nombre,
				precio: p.precio,
				cantidad: 1,
				tipo: p.tipo,
				stockDisp: p.stock
			}];
		});
		setQ("");
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "font-display text-3xl tracking-tight",
			children: "Vender"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-1 text-sm text-muted-foreground",
			children: "Cobra en caja o carga a la habitación."
		})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid gap-4 lg:grid-cols-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
				className: "lg:col-span-2",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "relative mb-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "pointer-events-none absolute top-1/2 left-3 size-4 -translate-y-1/2 text-muted-foreground" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							className: "pl-10",
							placeholder: "Buscar snack, aseo o lavandería…",
							value: q,
							onChange: (e) => setQ(e.target.value)
						}),
						results.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "absolute z-10 mt-1 w-full overflow-hidden rounded-lg border border-border bg-card shadow-sm",
							children: results.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								className: "flex w-full items-center justify-between px-3 py-2.5 text-left text-sm hover:bg-muted",
								onClick: () => add(p),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [p.nombre, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "ml-2 text-xs text-muted-foreground",
									children: p.categoria
								})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "tabular",
									children: money(p.precio)
								})]
							}, p.id))
						})
					]
				}), cart.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "py-10 text-center text-sm text-muted-foreground",
					children: "Agrega productos o servicios."
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("table", {
					className: "w-full text-sm",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: cart.map((i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
						className: "border-b border-border last:border-0",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "py-2 font-medium",
								children: i.nombre
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
								className: "py-2 text-center",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										className: "size-8 rounded-md bg-muted",
										onClick: () => setCart((c) => c.map((x) => x.id === i.id ? {
											...x,
											cantidad: x.cantidad - 1
										} : x).filter((x) => x.cantidad > 0)),
										children: "−"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "mx-2 tabular",
										children: i.cantidad
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										className: "size-8 rounded-md bg-muted",
										onClick: () => {
											const p = products.find((x) => x.id === i.id);
											if (p) add(p);
										},
										children: "+"
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "py-2 text-right tabular",
								children: money(i.precio * i.cantidad)
							})
						]
					}, i.id)) })
				})] })
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, {
				className: "space-y-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-base",
						children: "Resumen"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex justify-between text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-muted-foreground",
							children: "Subtotal"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "tabular",
							children: money(sub)
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Descuento",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							type: "number",
							min: "0",
							step: "0.01",
							value: descuento,
							onChange: (e) => setDescuento(e.target.value)
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex justify-between border-t border-border pt-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-medium",
							children: "Total"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-display text-xl tabular",
							children: money(total)
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Cobrar a",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(NativeSelect, {
							value: destino,
							onChange: (e) => setDestino(e.target.value),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "caja",
								children: "Caja"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "habitacion",
								children: "Habitación"
							})]
						})
					}),
					destino === "habitacion" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Habitación",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(NativeSelect, {
							value: folioId,
							onChange: (e) => setFolioId(e.target.value),
							children: [folios.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "",
								children: "Sin ocupadas"
							}), folios.map((f) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
								value: f.id,
								children: [
									"Hab ",
									f.habNumero,
									" · ",
									f.huesped
								]
							}, f.id))]
						})
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Pago",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(NativeSelect, {
							value: metodo,
							onChange: (e) => setMetodo(e.target.value),
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "Efectivo" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "Tarjeta" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "Transferencia" })
							]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						className: "w-full",
						disabled: !cart.length,
						onClick: () => {
							const msg = sell({
								items: cart,
								descuento: Number(descuento) || 0,
								destino,
								folioId,
								metodo
							});
							if (!msg) return;
							if (msg.startsWith("Sin") || msg.startsWith("Selecciona") || msg.startsWith("Agrega")) {
								toast.error(msg);
								return;
							}
							toast.success(msg);
							setCart([]);
							setDescuento("0");
						},
						children: "Confirmar"
					})
				]
			}) })]
		})]
	});
}
function FoliosView() {
	const folios = useHotel((s) => s.folios);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "font-display text-3xl tracking-tight",
			children: "Cuentas abiertas"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-1 text-sm text-muted-foreground",
			children: "Alojamiento, snacks, aseo y lavadas cargados."
		})] }), folios.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "py-12 text-center text-sm text-muted-foreground",
			children: "No hay habitaciones ocupadas."
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "grid gap-4 md:grid-cols-2",
			children: folios.map((f) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-start justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "font-display text-xl",
						children: ["Hab ", f.habNumero]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted-foreground",
						children: f.huesped
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-xs text-muted-foreground",
						children: [
							formatDate(f.entrada),
							" → ",
							formatDate(f.salidaPrevista)
						]
					})
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-display text-xl tabular",
					children: money(f.total)
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-3 space-y-1 border-t border-border pt-3 text-xs",
				children: f.cargos.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "flex justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
						c.concepto,
						" ×",
						c.cantidad
					] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "tabular",
						children: money(c.total)
					})]
				}, c.id))
			})] }) }, f.id))
		})]
	});
}
function HistoryView() {
	const list = [...useHotel((s) => s.sales)].sort((a, b) => b.fecha.localeCompare(a.fecha));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "font-display text-3xl tracking-tight",
			children: "Historial"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-1 text-sm text-muted-foreground",
			children: "Ventas de mostrador y check-outs cobrados."
		})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "overflow-x-auto",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
				className: "w-full min-w-[640px] text-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
					className: "border-b border-border bg-muted/60 text-left text-xs text-muted-foreground",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "px-4 py-3 font-medium",
							children: "Fecha"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "px-4 py-3 font-medium",
							children: "Tipo"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "px-4 py-3 font-medium",
							children: "Detalle"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "px-4 py-3 text-right font-medium",
							children: "Total"
						})
					] })
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: list.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
					colSpan: 4,
					className: "px-4 py-10 text-center text-muted-foreground",
					children: "Sin movimientos."
				}) }) : list.map((v) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
					className: "border-b border-border last:border-0",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "px-4 py-3",
							children: formatDateTime(v.fecha)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "px-4 py-3",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
								variant: v.tipo === "checkout" ? "info" : "available",
								children: v.tipo === "checkout" ? "Check-out" : "Venta"
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "max-w-xs truncate px-4 py-3",
							children: v.detalle
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "px-4 py-3 text-right tabular font-medium",
							children: money(v.total)
						})
					]
				}, v.id)) })]
			})
		}) })]
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HotelApp, {});
}
//#endregion
export { Home as component };
